// Tipo de dato enumerado que representa las posibles notificaciones
// que puede recibir un suscriptor segun sus intereses
public enum EventoNotificacion {
    NUEVO_VIDEO,
    EN_VIVO,
    ANUNCIO_IMPORTANTE;
}