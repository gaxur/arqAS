package es.unizar.eina.M15_camping.test;

import android.app.Application;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import es.unizar.eina.M15_camping.database.Parcela;
import es.unizar.eina.M15_camping.database.ParcelaRepository;
import es.unizar.eina.M15_camping.database.Reserva;
import es.unizar.eina.M15_camping.database.ReservaRepository;

/**
 * Clase SobrecargayVolumen encargada de realizar pruebas de rendimiento y volumen
 * en las entidades de Parcela y Reserva. Incluye inserciones masivas, eliminaciones
 * y pruebas de longitud máxima para descripciones de parcelas.
 */
public class SobrecargayVolumen {
    private final Application application;

    /**
     * Constructor de la clase SobrecargayVolumen.
     *
     * @param application Contexto de la aplicación utilizado para acceder a los repositorios.
     */
    public SobrecargayVolumen(Application application) {
        this.application = application;
    }

    /**
     * Realiza pruebas de inserción masiva de 100 parcelas y 10,000 reservas.
     * Verifica la correcta creación de registros en la base de datos.
     * Utiliza un `ExecutorService` con un pool de 10 hilos para mejorar el rendimiento.
     */
    public void runVolumenTest() {
        ParcelaRepository parcelaRepository = new ParcelaRepository((Application) application);
        ReservaRepository reservaRepository = new ReservaRepository((Application) application);
        // Crear un listado para almacenar los resultados de los tests
        List<String> results = new ArrayList<>();
        ExecutorService executorService = Executors.newFixedThreadPool(10); // Usar múltiples hilos para mejorar el rendimiento

        // Añadir 100 parcelas válidas
        for (int i = 1; i <= 100; i++) {
            final int index = i;
            Future<Long> futureParcela = executorService.submit(new Callable<Long>() {
                @Override
                public Long call() {
                    try {
                        String parcelaNombre = "Parcela_" + index;
                        int maxOcupantes = index <= 50 ? 5 : 10;
                        double precioPersona = 10.0 + (index % 5);
                        String descripcion = "Descripción de la parcela " + index;
                        Parcela parcela = new Parcela(parcelaNombre, maxOcupantes, precioPersona, descripcion);
                        // Insertar parcela en el repositorio
                        return parcelaRepository.insert(parcela);
                    } catch (Exception e) {
                        return -1L; // Error en la inserción
                    }
                }
            });

            try {
                long parcelaId = futureParcela.get(); // Esperar a que la inserción termine
                if (parcelaId != -1) {
                    results.add("Parcela " + "Parcela_" + index + ": OK");
                } else {
                    results.add("Parcela " + "Parcela_" + index + ": ERROR");
                }
            } catch (Exception e) {
                results.add("Parcela " + "Parcela_" + index + ": ERROR");
            }
        }
        final Integer[] fecha = {2025};  // Año inicial

        // Añadir 10,000 reservas válidas
        for (int i = 1; i <= 10000; i++) {
            final int index = i;
            Future<Long> futureReserva = executorService.submit(new Callable<Long>() {
                @Override
                public Long call() {
                    try {
                        fecha[0] += 1;  // Incrementar el año en cada iteración
                        // Crear las fechas de entrada y salida de la reserva
                        String fechaStrEntrada = fecha[0] + "-02-01";  // Construir la fecha como cadena
                        String fechaStrSalida = fecha[0] + "-02-02";  // Construir la fecha como cadena

                        // Convertir las cadenas a Date usando SimpleDateFormat
                        Date fechaEntrada = new SimpleDateFormat("yyyy-MM-dd").parse(fechaStrEntrada);
                        Date fechaSalida = new SimpleDateFormat("yyyy-MM-dd").parse(fechaStrSalida);

                        String nombreCliente = "Cliente_" + index;
                        String telefono = String.format("%09d", 600000000 + index);// Generar teléfono de manera secuencial
                        double precioTotal = 10.0 * (index % 5); // Generar precios entre 10.0 y 15.0

                        // Crear la reserva
                        Reserva reserva = new Reserva(fechaEntrada, fechaSalida, nombreCliente, telefono, precioTotal);

                        // Insertar reserva en el repositorio
                        return reservaRepository.insert(reserva);
                    } catch (Exception e) {
                        return -1L; // Error en la inserción
                    }
                }
            });

            try {
                long reservaId = futureReserva.get(); // Esperar a que la inserción termine
                if (reservaId != -1) {
                    System.out.println("Reserva Cliente_" + index + ": OK");
                } else {
                    System.out.println("Reserva Cliente_" + index + ": ERROR");
                }
            } catch (Exception e) {
                System.out.println("Reserva Cliente_" + index + ": ERROR");
            }
        }

        // Mostrar los resultados de los tests
        for (String result : results) {
            System.out.println(result);
        }
    }

    /**
     * Elimina 100 parcelas y 10,000 reservas previamente creadas en la base de datos.
     * Utiliza un `ExecutorService` para paralelizar las operaciones de eliminación.
     */
    public void deleteAllParcelasAndReservas() {
        ParcelaRepository parcelaRepository = new ParcelaRepository((Application) application);
        ReservaRepository reservaRepository = new ReservaRepository((Application) application);
        // Crear un listado para almacenar los resultados de los tests
        List<String> results = new ArrayList<>();
        ExecutorService executorService = Executors.newFixedThreadPool(10); // Usar múltiples hilos para mejorar el rendimiento

        // Eliminar 100 parcelas válidas
        for (int i = 1; i <= 100; i++) {
            final int index = i;
            Future<Integer> futureParcela = executorService.submit(new Callable<Integer>() {
                @Override
                public Integer call() {
                    try {
                        String parcelaNombre = "Parcela_" + index;
                        // Buscar la parcela por nombre (o ID) para eliminarla
                        Parcela parcela = parcelaRepository.getParcelaByName(parcelaNombre);
                        if (parcela != null) {
                            // Eliminar la parcela
                            return parcelaRepository.delete(parcela);
                        } else {
                            return -1;
                        }
                    } catch (Exception e) {
                        return -1; // Error en la eliminación
                    }
                }
            });

            try {
                int deleteResult = futureParcela.get(); // Esperar a que la eliminación termine
                if (deleteResult != -1) {
                    results.add("Parcela " + "Parcela_" + index + ": OK");
                } else {
                    results.add("Parcela " + "Parcela_" + index + ": ERROR");
                }
            } catch (Exception e) {
                results.add("Parcela " + "Parcela_" + index + ": ERROR");
            }
        }

        // Eliminar 10,000 reservas válidas
        for (int i = 1; i <= 10000; i++) {
            final int index = i;
            Future<Integer> futureReserva = executorService.submit(new Callable<Integer>() {
                @Override
                public Integer call() {
                    try {
                        String nombreCliente = "Cliente_" + index;
                        // Buscar la reserva por nombre (o ID) para eliminarla
                        Reserva reserva = reservaRepository.getReservaByCliente(nombreCliente);
                        if (reserva != null) {
                            // Eliminar la reserva
                            return reservaRepository.delete(reserva);
                        } else {
                            return -1;
                        }
                    } catch (Exception e) {
                        return -1; // Error en la eliminación
                    }
                }
            });

            try {
                int deleteResult = futureReserva.get(); // Esperar a que la eliminación termine
                if (deleteResult != -1) {
                    results.add("Reserva " + "Cliente_" + index + ": OK");
                } else {
                    results.add("Reserva " + "Cliente_" + index + ": ERROR");
                }
            } catch (Exception e) {
                results.add("Reserva " + "Cliente_" + index + ": ERROR");
            }
        }

        // Esperar que todos los hilos terminen
        executorService.shutdown();
        while (!executorService.isTerminated()) {
        }

        // Mostrar los resultados de los tests
        for (String result : results) {
            System.out.println(result);
        }
    }

    public void testLongitudMaximaDescripcionParcela() {
        ParcelaRepository parcelaRepository = new ParcelaRepository((Application) application);
        // Crear un listado para almacenar los resultados de las pruebas
        List<String> results = new ArrayList<>();

        // Crear una descripción inicial corta
        String baseDescripcion = "Parcela con descripción larga. ";

        // Empezamos con una longitud inicial para la descripción
        int longitudDescripcion = 500; // Comenzamos con 100 caracteres

        // Recorremos las descripciones de longitud creciente
        while (true) {
            try {
                // Crear una descripción con la longitud actual
                String descripcion = baseDescripcion;
                while (descripcion.length() < longitudDescripcion) {
                    descripcion += baseDescripcion; // Aumentamos la longitud de la descripción
                }

                // Crear la parcela con la descripción
                Parcela parcela = new Parcela("Parcela_Larga_" + longitudDescripcion, 10, 10.0, descripcion);

                // Insertar la parcela en el repositorio
                parcelaRepository.insert(parcela);

                // Registrar el tamaño de la descripción en el Log
                Log.d("TestLongitudDescripcion", "Longitud de la descripción: " + descripcion.length());

                // Aumentamos la longitud de la descripción para la próxima iteración
                longitudDescripcion += 100; // Aumentamos 100 caracteres en cada iteración

            } catch (Exception e) {
                // Si ocurre una excepción, registramos el error y salimos
                Log.e("TestLongitudDescripcion", "Error al insertar parcela con descripción de " + longitudDescripcion + " caracteres", e);
                break;
            }
        }


    }


}
