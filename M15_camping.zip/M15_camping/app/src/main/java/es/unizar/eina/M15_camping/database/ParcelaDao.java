package es.unizar.eina.M15_camping.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;


/**
 * Interfaz que define las operaciones con acceso a datos y consultas para la tabla Parcela.
 * Utiliza las anotaciones de Room para definir las operaciones de acceso a la base de datos.
 */
@Dao
public interface ParcelaDao {

    /**
     * Inserta una nueva parcela en la tabla.
     * Si ya existe una parcela con el mismo ID, ignora la inserción.
     *
     * @param parcela El objeto {@link Parcela} a insertar.
     * @return El ID de la fila insertada o -1 si se ignora la operacion.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Parcela parcela);

    /**
     * Actualiza una parcela existente en la tabla.
     *
     * @param parcela El objeto {@link Parcela} a actualizar.
     * @return El numero de filas afectadas por la operacion.
     */
    @Update
    int update(Parcela parcela);

    /**
     * Elimina una parcela existente de la tabla.
     *
     * @param parcela El objeto {@link Parcela} a eliminar.
     * @return El numero de filas afectadas por la operacion.
     */
    @Delete
    int delete(Parcela parcela);

    /**
     * Elimina todas las parcelas de la tabla.
     */
    @Query("DELETE FROM Parcela")
    void deleteAll();

    /**
     * Verifica si existe una parcela con el mismo nombre pero con un ID diferente.
     * Esta consulta se utiliza para evitar duplicados de nombres en la tabla.
     *
     * @param title El nombre de la parcela a verificar.
     * @param id    El ID de la parcela actual (para excluirla de la búsqueda).
     * @return {@code true} si existe otra parcela con el mismo nombre; {@code false} en caso contrario.
     */
    @Query("SELECT EXISTS(SELECT 1 FROM parcela WHERE title = :title AND id != :id LIMIT 1)")
    boolean parcelaExists(String title, int id);

    /**
     * Recupera todas las parcelas ordenadas alfabeticamente por nombre.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    @Query("SELECT * FROM Parcela ORDER BY title ASC")
    LiveData<List<Parcela>> getOrderedParcelasByName();

    /**
     * Recupera todas las parcelas ordenadas por ID de menor a mayor.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    @Query("SELECT * FROM Parcela ORDER BY id ASC")
    LiveData<List<Parcela>> getOrderedParcelasById();

    /**
     * Recupera todas las parcelas ordenadas por el número maximo de ocupantes de menor a mayor.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    @Query("SELECT * FROM Parcela ORDER BY nMaxOcup ASC")
    LiveData<List<Parcela>> getOrderedParcelasByMaxOccupants();

    /**
     * Recupera todas las parcelas ordenadas por precio de menor a mayor.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    @Query("SELECT * FROM Parcela ORDER BY precioPersona ASC")
    LiveData<List<Parcela>> getOrderedParcelasByPrice();

    /**
     * Obtiene una parcela de la base de datos por su nombre.
     * Esta consulta busca una parcela utilizando su nombre como filtro.
     *
     * @param parcelaNombre El nombre de la parcela que se desea buscar.
     * @return La parcela con el nombre especificado, o null si no se encuentra.
     */
    @Query("SELECT * FROM parcela WHERE title = :parcelaNombre LIMIT 1")
    Parcela getParcelaByName(String parcelaNombre);

    /**
     * Obtiene una parcela de la base de datos por su id.
     * Esta consulta busca una parcela utilizando su id como filtro.
     *
     * @param parcelaId El id de la parcela que se desea buscar.
     * @return La parcela con el id especificado, o null si no se encuentra.
     */
    @Query("SELECT * FROM Parcela WHERE id = :parcelaId LIMIT 1")
    Parcela getParcelaById(int parcelaId);


    /**
     * Elimina una parcela específica por su ID.
     *
     * @param parcelaId El ID de la parcela a eliminar.
     */
    @Query("DELETE FROM parcela WHERE id = :parcelaId")
    void deleteReservaById(int parcelaId);
}

