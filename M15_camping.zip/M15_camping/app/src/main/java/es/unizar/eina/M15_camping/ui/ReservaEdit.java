package es.unizar.eina.M15_camping.ui;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.concurrent.Executors;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.database.Reserva;
import es.unizar.eina.M15_camping.database.ReservaRepository;

public class ReservaEdit extends AppCompatActivity {

    public static final String RESERVA_ID = "id";
    public static final String RESERVA_FECHA_ENTRADA = "fechaEntrada";
    public static final String RESERVA_FECHA_SALIDA = "fechaSalida";
    public static final String RESERVA_NOM_CLIENTE = "nomCliente";
    public static final String RESERVA_NUM_CLIENTE = "numCliente";
    public static final String RESERVA_PRECIO_TOTAL = "precioTotal";

    private EditText mFechaEntradaText;
    private EditText mFechaSalidaText;
    private EditText mNomClienteText;
    private EditText mNumClienteText;

    private Integer mRowId;
    private boolean isTemporalSaved = false; // Indica si la reserva temporal se guardó
    private boolean parcelasAsociadas = false; // Indica si hay parcelas asociadas
    private boolean isEditing = false;

    private ReservaRepository reservaRepository;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Método que se llama cuando la actividad es creada. Aquí se inicializan los componentes de la interfaz de usuario
     * y se configuran los listeners para los botones de modificar parcelas y guardar la reserva.
     *
     * Además, se verifica si se está editando una reserva existente o creando una nueva, y se rellenan los campos
     * correspondientes con los datos de la reserva si es el caso.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservaedit);

        reservaRepository = new ReservaRepository(getApplication());

        mFechaEntradaText = findViewById(R.id.fechaEntrada);
        mFechaSalidaText = findViewById(R.id.fechaSalida);
        mNomClienteText = findViewById(R.id.nomCliente);
        mNumClienteText = findViewById(R.id.numCliente);

        Button modificarParcelas = findViewById(R.id.button_add_parcelas);
        Button mSaveButton = findViewById(R.id.button_save);

        modificarParcelas.setOnClickListener(view -> {
            if (checkEmptyFields()) {
                modificarParcelas(); // Asegurarse de que las fechas y otros campos estén completos
            }
        });

        mSaveButton.setOnClickListener(view -> {
            if ((checkEmptyFields() && parcelasAsociadas) || isEditing) {
                saveReserva();
            } else if (!parcelasAsociadas) {
                Toast.makeText(this, "Debes añadir al menos una parcela a la reserva.", Toast.LENGTH_SHORT).show();
            }
        });

        populateFields(); // Rellenar los datos de la reserva si está en modo edición
    }

    /**
     * Método que gestiona la modificación de las parcelas asociadas a la reserva. Si la reserva no ha sido guardada
     * temporalmente, se guarda primero. Luego, si las fechas de entrada y salida son válidas, se redirige a la pantalla
     * de edición de parcelas para asociar parcelas a la reserva.
     *
     * Si las fechas no son válidas o hay algún error, muestra un mensaje de advertencia.
     */
    private void modificarParcelas() {
        if (mRowId == null) {
            mRowId = guardarReservaTemporal();
        }

        if (mRowId != null) {
            try {
                // Obtener las fechas de entrada y salida
                long fechaEntrada = dateFormat.parse(mFechaEntradaText.getText().toString()).getTime();
                long fechaSalida = dateFormat.parse(mFechaSalidaText.getText().toString()).getTime();

                // Verificar si las fechas son válidas
                if (fechaEntrada >= fechaSalida) {
                    Toast.makeText(this, "La fecha de salida debe ser posterior a la fecha de entrada.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Crear el intent y pasar los datos necesarios
                Intent intent = new Intent(this, ReservaEditParcela.class);
                intent.putExtra("RESERVA_ID", mRowId);
                intent.putExtra("FECHA_ENTRADA", fechaEntrada);
                intent.putExtra("FECHA_SALIDA", fechaSalida);
                startActivity(intent);

                // Verificar si se añaden parcelas tras modificar
                Executors.newSingleThreadExecutor().execute(() -> {
                    int count = reservaRepository.getParcelasCountByReservaId(mRowId);
                    runOnUiThread(() -> parcelasAsociadas = count > 0);
                });
            } catch (ParseException e) {
                Toast.makeText(this, "Error en el formato de las fechas.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Error al guardar la reserva temporal.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Método que se llama cuando la actividad vuelve a estar en primer plano.
     * Se verifica si hay parcelas asociadas a la reserva y actualiza el estado de `parcelasAsociadas`.
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (mRowId != null) {
            verificarParcelasAsociadas();
        }
    }

    /**
     * Método que verifica si existen parcelas asociadas a la reserva.
     * Actualiza la variable `parcelasAsociadas` para reflejar el estado de la relación entre la reserva y las parcelas.
     */
    private void verificarParcelasAsociadas() {
        Executors.newSingleThreadExecutor().execute(() -> {
            int count = reservaRepository.getParcelasCountByReservaId(mRowId);
            runOnUiThread(() -> parcelasAsociadas = count > 0);
        });
    }

    /**
     * Método que se llama cuando el usuario presiona el botón de retroceder. Si se ha guardado una reserva temporal,
     * se eliminan las parcelas asociadas y la reserva temporal antes de que la actividad se cierre.
     */
    @Override
    public void onBackPressed() {
        if (isTemporalSaved && mRowId != null) {
            Executors.newSingleThreadExecutor().execute(() -> {
                reservaRepository.deleteParcelaReserva(mRowId); // Eliminar todas las parcelas asociadas
                reservaRepository.deleteReservaById(mRowId); // Eliminar la reserva temporal
            });
        }
        super.onBackPressed();
    }

    /**
     * Método que guarda una reserva temporal en la base de datos. Si ya existe una reserva con el mismo ID,
     * no se crea una nueva. Si se guarda correctamente, se establece el indicador `isTemporalSaved` como verdadero.
     *
     * @return El ID de la reserva guardada si la operación fue exitosa, o `null` si ocurrió un error al guardar.
     */
    private Integer guardarReservaTemporal() {
        if (mRowId != null) {
            return mRowId; // Si ya existe, no crear otra vez
        }

        try {
            Date fechaEntrada = dateFormat.parse(mFechaEntradaText.getText().toString());
            Date fechaSalida = dateFormat.parse(mFechaSalidaText.getText().toString());

            Reserva nuevaReserva = new Reserva(
                    fechaEntrada,
                    fechaSalida,
                    mNomClienteText.getText().toString(),
                    mNumClienteText.getText().toString(),
                    0.0
            );

            long idGenerado = reservaRepository.insert(nuevaReserva);
            if (idGenerado > 0) {
                isTemporalSaved = true;
                return (int) idGenerado;
            } else {
                return null;
            }
        } catch (ParseException e) {
            Toast.makeText(this, "Error en el formato de la fecha.", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    /**
     * Método que guarda la reserva definitiva en la base de datos. Si la reserva es válida (es decir, tiene las fechas
     * de entrada y salida correctas, y todas las parcelas asociadas), se guarda la reserva permanentemente en la base
     * de datos.
     *
     * Si ocurre algún error durante el proceso, se muestra un mensaje indicando que la reserva no se ha podido guardar.
     */
    private void saveReserva() {
        if (mRowId != null) {
            try {
                // Parsear las fechas desde los campos de texto
                Date fechaEntrada = dateFormat.parse(mFechaEntradaText.getText().toString());
                Date fechaSalida = dateFormat.parse(mFechaSalidaText.getText().toString());



                // Crear una instancia de reserva con los datos actualizados
                Reserva reservaActualizada = new Reserva(
                        fechaEntrada,
                        fechaSalida,
                        mNomClienteText.getText().toString(),
                        mNumClienteText.getText().toString(),
                        0.0 // Precio total inicial, puede ser recalculado después
                );

                reservaActualizada.setId(mRowId); // Establecer el ID de la reserva

                // Ejecutar la actualización en la base de datos
                Executors.newSingleThreadExecutor().execute(() -> {
                    double precioTotal = reservaRepository.calculateTotalPrice(reservaActualizada.getId());
                    reservaActualizada.setPrecioTotal(precioTotal); // Asignar el precio calculado

                    int filasActualizadas = reservaRepository.update(reservaActualizada); // Actualizar la reserva
                    runOnUiThread(() -> {
                        if (filasActualizadas > 0) {
                            isTemporalSaved = true; // Indicar que la reserva ha sido guardada o actualizada
                            Toast.makeText(this, isEditing ? "Reserva actualizada correctamente." : "Reserva creada correctamente.", Toast.LENGTH_SHORT).show();


                            finish(); // Finalizar la actividad después de guardar
                        } else {
                            Toast.makeText(this, "Error al guardar la reserva.", Toast.LENGTH_SHORT).show();
                        }
                    });
                });
            } catch (ParseException e) {
                Toast.makeText(this, "Error en el formato de la fecha.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Debe haber al menos 1 parcela asociada a la reserva.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Verifica si los campos obligatorios de la reserva están completos. Los campos obligatorios son:
     * fecha de entrada, fecha de salida, nombre del cliente y número de cliente.
     *
     * @return `true` si todos los campos obligatorios están completos, `false` si alguno de ellos está vacío.
     */
    private boolean checkEmptyFields() {
        if (TextUtils.isEmpty(mFechaEntradaText.getText())) {
            Toast.makeText(this, "Por favor, introduce la fecha de entrada.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(mFechaSalidaText.getText())) {
            Toast.makeText(this, "Por favor, introduce la fecha de salida.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(mNomClienteText.getText())) {
            Toast.makeText(this, "Por favor, introduce el nombre del cliente.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(mNumClienteText.getText())) {
            Toast.makeText(this, "Por favor, introduce el número del cliente.", Toast.LENGTH_LONG).show();
            return false;
        }
        String numCliente = mNumClienteText.getText().toString();
        if (!esNumeroTelefonoValido(numCliente)) {
            Toast.makeText(this, "El número del cliente debe contener exactamente 9 dígitos.", Toast.LENGTH_LONG).show();
            return false;
        }

        // Validar fechas de entrada y salida
        String fechaEntradaStr = mFechaEntradaText.getText().toString();
        String fechaSalidaStr = mFechaSalidaText.getText().toString();

        if (!esFechaValida(fechaEntradaStr) || !esFechaValida(fechaSalidaStr)) {
            Toast.makeText(this, "Una o ambas fechas son inválidas.", Toast.LENGTH_LONG).show();
            return false;
        }

        if (!esFechaEntradaMenorQueFechaSalida(fechaEntradaStr, fechaSalidaStr)) {
            Toast.makeText(this, "La fecha de entrada debe ser menor que la fecha de salida.", Toast.LENGTH_LONG).show();
            return false;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!esFechaEntradaValida(fechaEntradaStr)){
                Toast.makeText(this, "La fecha de entrada debe ser igual o posterior a la fecha actual.", Toast.LENGTH_LONG).show();
                return false;
            }
        }
        return true;
    }

    /**
     * Valida si la fecha de entrada es igual o posterior a la fecha actual.
     *
     * Este método convierte la fecha de entrada proporcionada en formato de texto (String)
     * a un objeto {@link LocalDate}, y la compara con la fecha actual del sistema. Si la
     * fecha de entrada es anterior a la fecha actual, el método devuelve {@code false}.
     * Si la fecha de entrada es igual o posterior a la fecha actual, el método devuelve {@code true}.
     *
     * @param fechaEntradaStr La fecha de entrada en formato de texto (String) que se desea validar.
     *                       Se espera que la fecha esté en el formato "yyyy-MM-dd".
     *                       Si el formato es incorrecto, el método devuelve {@code false}.
     * @return {@code true} si la fecha de entrada es igual o posterior a la fecha actual;
     *         {@code false} si la fecha de entrada es anterior a la fecha actual o si el formato de fecha es inválido.
     * @throws DateTimeParseException Si la fecha de entrada no puede ser parseada correctamente debido a un formato incorrecto.
     */

    @RequiresApi(api = Build.VERSION_CODES.O)
    private boolean esFechaEntradaValida(String fechaEntradaStr) {
        try {
            // Definir el formato de la fecha (ajustar según tu formato)
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); // Suponiendo que la fecha es en formato "yyyy-MM-dd"
            LocalDate fechaEntrada = LocalDate.parse(fechaEntradaStr, formatter);
            LocalDate fechaActual = LocalDate.now();  // Fecha actual

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return !fechaEntrada.isBefore(fechaActual);  // Comprobar si la fecha de entrada no es anterior a la fecha actual
            }
        } catch (DateTimeParseException e) {
            // Si ocurre un error al parsear la fecha, la consideramos inválida
            return false;
        }
        return false;
    }

    /**
     * Comprueba si un número de teléfono es válido (exactamente 9 dígitos).
     *
     * @param numero El número de teléfono como cadena.
     * @return {@code true} si el número es válido, {@code false} en caso contrario.
     */
    private boolean esNumeroTelefonoValido(String numero) {
        return numero.matches("\\d{9}");
    }

    /**
     * Comprueba si una fecha es válida en formato "dd-MM-yyyy".
     *
     * @param fecha La fecha en formato "dd-MM-yyyy".
     * @return {@code true} si la fecha es válida, {@code false} en caso contrario.
     */
    private boolean esFechaValida(String fecha) {
        String[] partes = fecha.split("-");
        if (partes.length != 3) {
            return false; // Formato incorrecto
        }

        try {
            int dia = Integer.parseInt(partes[2]);
            int mes = Integer.parseInt(partes[1]);
            int anio = Integer.parseInt(partes[0]);

            return esFechaValida(dia, mes, anio); // Usa la función para verificar días del mes
        } catch (NumberFormatException e) {
            return false; // Los valores no son enteros
        }
    }

    /**
     * Comprueba si el día, mes y año son válidos.
     *
     * @param dia El día del mes (1-31).
     * @param mes El mes (1-12).
     * @param anio El año (por ejemplo, 2024).
     * @return {@code true} si la combinación de día, mes y año es válida, {@code false} en caso contrario.
     */
    private boolean esFechaValida(int dia, int mes, int anio) {
        if (mes < 1 || mes > 12) {
            return false; // Mes inválido
        }

        int[] diasPorMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        if (mes == 2 && esAnioBisiesto(anio)) {
            diasPorMes[1] = 29;
        }

        return dia >= 1 && dia <= diasPorMes[mes - 1];
    }

    /**
     * Comprueba si un año es bisiesto.
     *
     * @param anio El año a comprobar.
     * @return {@code true} si el año es bisiesto, {@code false} en caso contrario.
     */
    private boolean esAnioBisiesto(int anio) {
        return (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
    }

    /**
     * Comprueba si la fecha de entrada es menor que la fecha de salida.
     *
     * @param fechaEntrada La fecha de entrada en formato "dd-MM-yyyy".
     * @param fechaSalida  La fecha de salida en formato "dd-MM-yyyy".
     * @return {@code true} si la fecha de entrada es menor, {@code false} en caso contrario.
     */
    private boolean esFechaEntradaMenorQueFechaSalida(String fechaEntrada, String fechaSalida) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date entrada = dateFormat.parse(fechaEntrada);
            Date salida = dateFormat.parse(fechaSalida);
            return entrada.before(salida); // Comprueba si la fecha de entrada es anterior a la de salida
        } catch (ParseException e) {
            return false; // Error en el formato
        }
    }

    /**
     * Método que llena los campos de la interfaz de usuario con los datos de la reserva existente si se está editando
     * una reserva. Este método se llama al iniciar la actividad en modo edición.
     *
     * Si el ID de la reserva es válido, se obtienen los detalles de la reserva y se rellenan los campos de fecha de entrada,
     * fecha de salida, nombre del cliente y número de cliente con los valores correspondientes.
     */
    private void populateFields() {
        mRowId = null;
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if(extras.containsKey(RESERVA_ID)) {
                mRowId = extras.getInt(RESERVA_ID);
                isEditing = true; // Estas editando una reserva existente

                long fechaEntradaLong = extras.getLong(RESERVA_FECHA_ENTRADA, -1);
                long fechaSalidaLong = extras.getLong(RESERVA_FECHA_SALIDA, -1);

                if (fechaEntradaLong != -1) {
                    Date fechaEntrada = new Date(fechaEntradaLong);
                    mFechaEntradaText.setText(dateFormat.format(fechaEntrada));
                }

                if (fechaSalidaLong != -1) {
                    Date fechaSalida = new Date(fechaSalidaLong);
                    mFechaSalidaText.setText(dateFormat.format(fechaSalida));
                }

                mNomClienteText.setText(extras.getString(RESERVA_NOM_CLIENTE, ""));
                mNumClienteText.setText(extras.getString(RESERVA_NUM_CLIENTE, ""));
            }
            else{
                isEditing = false; //no se esta editando
            }

            // Aquí es donde se cambia el texto del botón dependiendo de si estamos editando o creando
            Button modificarParcelas = findViewById(R.id.button_add_parcelas);
            if (isEditing) {
                modificarParcelas.setText("Modificar num ocupantes");
            } else {
                modificarParcelas.setText("Añadir parcelas");
            }
        }
    }
}
