package es.unizar.eina.M15_camping.ui;

import android.annotation.SuppressLint;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import java.util.Objects;

import es.unizar.eina.M15_camping.database.Reserva;


/**
 * Adaptador para gestionar y mostrar una lista de reservas en un RecyclerView.
 * Utiliza {@link ListAdapter} para manejar eficientemente las actualizaciones.
 */
public class ReservaListAdapter extends ListAdapter<Reserva, ReservaViewHolder> {
    private int position;

    /**
     * Obtiene la posicion actual del elemento seleccionado en la lista.
     *
     * @return La posicion actual del elemento seleccionado.
     */
    public int getPosition() {
        return position;
    }

    /**
     * Establece la posicion del elemento seleccionado en la lista.
     *
     * @param position La posicion que se desea establecer como seleccionada.
     */
    public void setPosition(int position) {
        this.position = position;
    }

    /**
     * Constructor del adaptador.
     *
     * @param diffCallback El objeto {@link DiffUtil.ItemCallback} utilizado para calcular diferencias entre elementos.
     */
    public ReservaListAdapter(@NonNull DiffUtil.ItemCallback<Reserva> diffCallback) {
        super(diffCallback);
    }

    /**
     * Crea un nuevo {@link ReservaViewHolder} para representar un elemento de la lista.
     *
     * @param parent   El grupo de vistas al que se añadira la nueva vista.
     * @param viewType El tipo de vista del nuevo elemento.
     * @return Un nuevo {@link ReservaViewHolder}.
     */
    @Override
    public ReservaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return ReservaViewHolder.create(parent);
    }

    /**
     * Obtiene el elemento actualmente seleccionado en la lista.
     *
     * @return El objeto {@link Reserva} en la posicion seleccionada.
     */
    public Reserva getCurrent() {
        return getItem(getPosition());
    }

    /**
     * Vincula los datos del objeto {@link Reserva} a la vista representada por {@link ReservaViewHolder}.
     * Tambien configura un listener para manejar esperas/selecciones en los elementos.
     *
     * @param holder   El {@link ReservaViewHolder} que contiene la vista del elemento.
     * @param position La posicion del elemento en la lista.
     */
    @Override
    public void onBindViewHolder(ReservaViewHolder holder, int position) {

        Reserva current = getItem(position);
        holder.bind(current); // Pasar el objeto Parcela completo

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                setPosition(holder.getAdapterPosition());
                return false;
            }
        });
    }

    /**
     * Clase interna para calcular diferencias entre elementos de la lista de reservas.
     * Utilizada por {@link ListAdapter} para optimizar las actualizaciones del RecyclerView.
     */
    static class ReservaDiff extends DiffUtil.ItemCallback<Reserva> {

        /**
         * Comprueba si dos objetos {@link Reserva} representan el mismo elemento en la lista.
         *
         * @param oldItem El elemento antiguo.
         * @param newItem El nuevo elemento.
         * @return {@code true} si ambos objetos tienen el mismo ID; {@code false} en caso contrario.
         */
        @Override
        public boolean areItemsTheSame(@NonNull Reserva oldItem, @NonNull Reserva newItem) {
            //android.util.Log.d ( "NoteDiff" , "areItemsTheSame " + oldItem.getId() + " vs " + newItem.getId() + " " +  (oldItem.getId() == newItem.getId()));
            return oldItem.getId() == newItem.getId();
        }

        /**
         * Comprueba si los contenidos visuales de dos objetos {@link Reserva} son iguales.
         *
         * @param oldItem El elemento antiguo.
         * @param newItem El nuevo elemento.
         * @return {@code true} si los nombres de los clientes en ambas reservas son iguales; {@code false} en caso contrario.
         */
        @SuppressLint("DiffUtilEquals")
        @Override
        public boolean areContentsTheSame(@NonNull Reserva oldItem, @NonNull Reserva newItem) {
            //android.util.Log.d ( "NoteDiff" , "areContentsTheSame " + oldItem.getTitle() + " vs " + newItem.getTitle() + " " + oldItem.getTitle().equals(newItem.getTitle()));
            // We are just worried about differences in visual representation, i.e. changes in the title
            return oldItem.getNomCliente().equals(newItem.getNomCliente()) &&
                    oldItem.getFechaEntrada().equals(newItem.getFechaEntrada()) &&
                    Objects.equals(oldItem.getPrecioTotal(), newItem.getPrecioTotal());
        }
    }
}