package es.unizar.eina.send;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

/** Concrete implementor utilizando la aplicación de WhatsApp. */
public class WhatsAppImplementor implements SendImplementor {

   /** Actividad desde la cual se abrirá la aplicación de WhatsApp */
   private Activity sourceActivity;

   /**
    * Constructor
    *
    * @param source actividad desde la cual se abrirá la aplicación de WhatsApp
    */
   public WhatsAppImplementor(Activity source) {
      setSourceActivity(source);
   }

   /** Actualiza la actividad desde la cual se abrirá la actividad de gestión de correo */
   public void setSourceActivity(Activity source) {
      sourceActivity = source;
   }

   /** Recupera la actividad desde la cual se abrirá la aplicación de WhatsApp */
   public Activity getSourceActivity() {
      return sourceActivity;
   }

   /**
    * Implementación del método send utilizando la aplicación de WhatsApp
    *
    * @param phone   teléfono en formato internacional con código de país
    * @param message cuerpo del mensaje
    */
   public void send(String phone, String message) {
      try {
         Log.d("WhatsAppDebug", "Intentando enviar mensaje...");

         // Verificar si WhatsApp o WhatsApp Business están instalados
         String packageName = detectWhatsAppPackage();

         Log.d("WhatsAppDebug", "WhatsApp detectado: " + packageName);

         // Validar y formatear el número
         String formattedPhone = phone.startsWith("+") ? phone.replace("+", "") : "34" + phone; // Cambia "34" por el código de país
         Log.d("WhatsAppDebug", "Número formateado: " + formattedPhone);

         if (!formattedPhone.matches("\\d+")) {
            Log.e("WhatsAppDebug", "Número de teléfono inválido: " + formattedPhone);
            runOnUiThread(() ->
                    Toast.makeText(getSourceActivity(), "Número de teléfono no válido", Toast.LENGTH_SHORT).show()
            );
            return;
         }

         // Crear el URI con la API de WhatsApp
         String url = "https://wa.me/" + formattedPhone + "?text=" + Uri.encode(message);
         Uri uri = Uri.parse(url);
         Log.d("WhatsAppDebug", "URI generado: " + uri);

         // Crear el Intent
         Intent sendIntent = new Intent(Intent.ACTION_VIEW, uri);
         sendIntent.setPackage(packageName);

         // Iniciar WhatsApp
         getSourceActivity().startActivity(sendIntent);
         Log.d("WhatsAppDebug", "WhatsApp iniciado correctamente.");
      } catch (Exception e) {
         Log.e("WhatsAppError", "Error al iniciar WhatsApp", e);
         runOnUiThread(() ->
                 Toast.makeText(getSourceActivity(), "Error al abrir WhatsApp", Toast.LENGTH_SHORT).show()
         );
      }
   }

   /**
    * Detecta si WhatsApp o WhatsApp Business están instalados en el dispositivo.
    *
    * @return El nombre del paquete de WhatsApp o WhatsApp Business si están instalados, null en caso contrario.
    */
   private String detectWhatsAppPackage() {
      try {
         PackageManager pm = getSourceActivity().getPackageManager();
         Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"));

         List<ResolveInfo> resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);

         for (ResolveInfo resolveInfo : resolveInfos) {
            String packageName = resolveInfo.activityInfo.packageName;
            if (packageName.equals("com.whatsapp") || packageName.equals("com.whatsapp.w4b")) {
               return packageName;
            }
         }
      } catch (Exception e) {
         Log.e("WhatsAppDebug", "Error detectando paquetes de WhatsApp", e);
      }
      return null;
   }

   /**
    * Ejecuta el código en el hilo principal.
    *
    * @param runnable Código a ejecutar.
    */
   private void runOnUiThread(Runnable runnable) {
      new Handler(Looper.getMainLooper()).post(runnable);
   }
}
