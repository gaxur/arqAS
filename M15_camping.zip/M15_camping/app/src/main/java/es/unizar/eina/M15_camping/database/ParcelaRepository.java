package es.unizar.eina.M15_camping.database;


import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Clase que actua como una capa intermedia entre el DAO de {@link Parcela} y el resto de la aplicacion.
 * Proporciona metodos para realizar operaciones con acceso a los datos y consultas sobre las parcelas de forma asincrona.
 */
public class ParcelaRepository {

    private final ParcelaDao mParcelaDao;
    private final LiveData<List<Parcela>> mAllParcelas;

    private final long TIMEOUT = 15000;

    /**
     * Constructor de NoteRepository utilizando el contexto de la aplicacion para instanciar la base de datos.
     *
     * @param application La aplicacion que contiene el contexto.
     */
    public ParcelaRepository(Application application) {
        ParcelaReservaRoomDatabase db = ParcelaReservaRoomDatabase.getDatabase(application);
        mParcelaDao = db.parcelaDao();
        mAllParcelas = mParcelaDao.getOrderedParcelasByName(); // realmente no es necesario si se
                                                            // invoca con la funcion directamente
    }

    /**
     * Devuelve un objeto de tipo LiveData con todas las parcelas ordenadas por nombre alfabeticamente.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getAllParcelasOrderedByName() {
        return mAllParcelas;
    }

    /**
     * Devuelve un objeto de tipo LiveData con todas las parcelas ordenadas por ID de menor a mayor.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getParcelasOrderedById() {
        return mParcelaDao.getOrderedParcelasById();
    }

    /**
     * Devuelve un objeto de tipo LiveData con todas las parcelas ordenadas por numero maximo de ocupantes de menor a mayor.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getParcelasOrderedByMaxOccupants() {
        return mParcelaDao.getOrderedParcelasByMaxOccupants();
    }

    /**
     * Devuelve un objeto de tipo LiveData con todas las parcelas ordenadas por precio de menor a mayor.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     * */
    public LiveData<List<Parcela>> getParcelasOrderedByPrice() {
        return mParcelaDao.getOrderedParcelasByPrice();
    }

    /**
     * Inserta una parcela nueva en la base de datos
     *
     * @param parcela El objeto {@link Parcela} que se desea insertar.
     * @return El ID de la parcela insertada o -1 si ocurrio un error.
     */
    public long insert(Parcela parcela) {
        // Al gestionar como @PrimaryKey un id interno en vez del nombre de la parcela
        // se restringe en esta operación de inserción para que no suceda
        Future<Long> future = ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(() -> {
            // Verifica si la parcela ya existe antes de insertar
            // Se podria implementar de forma similar con el uso de CHECKS
            if (!parcelaExists(parcela.getTitle(), parcela.getId()) && parcela.getNMaxOcup() > 0 && parcela.getPrecioPersona() > 0.0) {
                return mParcelaDao.insert(parcela); // Inserta si no existe
            }
            return -1L; // Retorna -1 si la parcela ya existe
        });

        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ParcelaRepository", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return -1;
        }
    }


    /**
     * Actualiza una parcela en la base de datos
     *
     * @param parcela El objeto {@link Parcela} que se desea actualizar.
     * @return El numero de filas afectadas o -1 si ocurrio un error.
     */
    public int update(Parcela parcela) {
        Future<Integer> future = ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(() -> {
            // Validaciones previas
            if (parcela.getTitle() == null || parcela.getNMaxOcup() == null || parcela.getPrecioPersona() == null) {
                Log.d("ParcelaRepository", "Error: Campos nulos no permitidos en la actualización");
                return -1; // No se permite actualizar con valores nulos
            }

            if (parcelaExists(parcela.getTitle(), parcela.getId())) {
                Log.d("ParcelaRepository", "Error: Título de parcela ya existe en otra parcela");
                return -1; // Título duplicado
            }

            if (parcela.getNMaxOcup() <= 0 || parcela.getPrecioPersona() <= 0.0) {
                Log.d("ParcelaRepository", "Error: Valores inválidos (nMaxOcup <= 0 o precioPersona <= 0)");
                return -1; // Valores inválidos
            }

            // Realizar la actualización si pasa todas las validaciones
            return mParcelaDao.update(parcela);
        });

        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ParcelaRepository", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return -1; // Error durante la actualización
        }
    }


    /**
     * Elimina una parcela en la base de datos
     *
     * @param parcela El objeto {@link Parcela} que se desea eliminar.
     * @return El numero de filas afectadas o -1 si ocurrio un error.
     */
    public int delete(Parcela parcela) {
        Log.d("ParcelaRepository", "Intentando eliminar parcela: " + parcela.toString());  // Log de la parcela que estamos intentando eliminar

        Future<Integer> future = ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(() -> {
            if (parcela.getBody() != null && parcela.getTitle() != null && parcela.getPrecioPersona() != null && parcela.getNMaxOcup() != null) {
                Log.d("ParcelaRepository", "La parcela es válida, eliminando...");  // Log para saber si la parcela es válida para eliminar
                mParcelaDao.delete(parcela);  // Eliminar parcela si es válida
                Log.d("ParcelaRepository", "Parcela eliminada con éxito: " + parcela.toString());  // Log de éxito
            } else {
                Log.d("ParcelaRepository", "La parcela no es válida para eliminar. Falta algún campo.");  // Log si la parcela no es válida
            }
            return 0;  // Indicamos que no se produjo ningún error
        });

        try {
            int result = future.get(TIMEOUT, TimeUnit.MILLISECONDS);  // Esperamos el resultado
            Log.d("ParcelaRepository", "Resultado de la eliminación: " + result);  // Log del resultado de la eliminación
            return result;
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ParcelaRepository", "Error al eliminar parcela: " + ex.getClass().getSimpleName() + " - " + ex.getMessage());  // Log del error
            return -1;  // Si hubo un error, retornamos -1
        }
    }

    public void deleteAllParcelas() {
        ParcelaReservaRoomDatabase.databaseWriteExecutor.execute(() -> mParcelaDao.deleteAll());
    }

    /**
     * Verifica si una parcela con el nombre dado ya existe en la base de datos
     *
     * @param title El nombre de la parcela que se desea verificar.
     * @param id    El ID de la parcela actual (para excluirla en la busqueda, si aplica).
     * @return {@code true} si existe una parcela con el mismo nombre; {@code false} en caso contrario.
     */
    public boolean parcelaExists(String title, int id) {
        Future<Boolean> future = ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(
                () -> mParcelaDao.parcelaExists(title, id)
        );
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Obtiene una parcela por su nombre desde la base de datos.
     *
     * @param parcelaNombre El nombre de la parcela.
     * @return La parcela correspondiente, o null si no se encuentra.
     */
    public Parcela getParcelaByName(String parcelaNombre) {
        return mParcelaDao.getParcelaByName(parcelaNombre);
    }

    /**
     * Recupera una parcela específica de la base de datos a partir de su ID.
     *
     * @param parcelaId El identificador único de la parcela.
     * @return La Parcela correspondiente al ID proporcionado, o null si no existe.
     */
    public Parcela getParcelaById(int parcelaId) {
        try {
            return ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(() ->
                    mParcelaDao.getParcelaById(parcelaId)
            ).get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * Elimina una parcela específica por su ID.
     *
     * @param parcelaId El ID de la parcela a eliminar.
     */
    public void deleteById(int parcelaId) {
        Executors.newSingleThreadExecutor().execute(() -> {
            mParcelaDao.deleteReservaById(parcelaId);
        });
    }
}
