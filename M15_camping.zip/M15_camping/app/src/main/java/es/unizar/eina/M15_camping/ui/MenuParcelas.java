package es.unizar.eina.M15_camping.ui;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.test.SobrecargayVolumen;
import es.unizar.eina.M15_camping.test.UnitTests;
import static androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;

import static java.lang.Thread.sleep;

import java.util.List;


/**
 * Actividad principal de la aplicacion para gestionar el menu de parcelas.
 * Permite listar, crear, editar y eliminar parcelas, asi como ordenarlas y cambiar a la pantalla de reservas.
 */
public class MenuParcelas extends AppCompatActivity {
    private ParcelaViewModel mParcelaViewModel;

    static final int DELETE_ID = Menu.FIRST + 1;
    static final int EDIT_ID = Menu.FIRST + 2;
    static final int CHANGE_ID_PARCELA = Menu.FIRST + 3;
    static final int ORD_ID_ID = Menu.FIRST + 4;
    static final int ORD_ID_NMAXOCUP = Menu.FIRST + 5;
    static final int ORD_ID_PRECIOPERSONA = Menu.FIRST + 6;

    RecyclerView mRecyclerView;

    ParcelaListAdapter mAdapter;

    FloatingActionButton mFab;
    Button ordButton;

    Button testButton;

    /**
     * Inicializa la actividad y configura la lista de parcelas, el ViewModel y los botones tanto
     * para crear una parcela, como para ordenarlas.
     * @param savedInstanceState Estado guardado de la instancia anterior (inicializacion y configuracion).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcela);

        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new ParcelaListAdapter(new ParcelaListAdapter.ParcelaDiff());
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mParcelaViewModel.getAllParcelasOrderedByName().observe(this, parcelas -> {
            // Actualiza la copia en caché de las parcelas en el adaptador.
            mAdapter.submitList(parcelas);
        });

        mFab = findViewById(R.id.fab);
        mFab.setOnClickListener(view -> createParcela());

        // añadimos el botón para ordenar
        ordButton = findViewById(R.id.ordButton);
        ordButton.setOnClickListener(view -> onOrderOptionMenu());

        // añadimos el botón para ejecutar los tests de Parcelas
        registerForContextMenu(mRecyclerView);
        testButton = findViewById(R.id.testButton);
        TextView testResults = findViewById(R.id.testResultsTextView); // Asumiendo que el TextView tiene este ID

        testButton.setOnClickListener(view -> {
            // Cambié 'this' por 'getApplicationContext()' para pasar el contexto correcto
            UnitTests tests = new UnitTests(getApplication());
            List<String> results = tests.ejecutarTests("parcelas");

            testResults.setVisibility(View.VISIBLE);
            StringBuilder resultText = new StringBuilder();
            for (String result : results) {
                resultText.append(result).append("\n");
            }
            testResults.setText(resultText.toString());
        });

        SobrecargayVolumen sobrecargayVolumenTest = new SobrecargayVolumen(getApplication());

        // Botón para ejecutar las pruebas de volumen
        Button volumenTestButton = findViewById(R.id.volumenTestButton);
        volumenTestButton.setOnClickListener(view -> {
            // Ejecuta las pruebas de volumen
            sobrecargayVolumenTest.runVolumenTest();
        });

        // Botón para eliminar todas las parcelas y reservas
        Button eliminarButton = findViewById(R.id.eliminarButton);
        eliminarButton.setOnClickListener(view -> {
            // Elimina todas las parcelas y reservas
            sobrecargayVolumenTest.deleteAllParcelasAndReservas();
        });

        // Botón para prueba de Sobrecarga
        Button Sobrecargabutton = findViewById(R.id.Sobrecargabutton);
        Sobrecargabutton.setOnClickListener(view -> {
            // Elimina todas las parcelas y reservas
            sobrecargayVolumenTest.testLongitudMaximaDescripcionParcela();
        });
    }

    /**
     * Crea un menu de opciones que incluye la opcion de cambiar a la pantalla de reservas.
     * @param menu El menu donde se agregara la opcion de cambiar a Reservas.
     * @return {@code true} si se crea correctamente, {@code false} en caso contrario.
     */

    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(Menu.NONE, CHANGE_ID_PARCELA, Menu.NONE, R.string.change_reserva);
        return result;
    }


    /**
     * Muestra un menu emergente (popup) con opciones para ordenar la lista de parcelas.
     * @return {@code true} si se utiliza de forma correcta, {@code false} en caso contrario.
     */
    public boolean onOrderOptionMenu() {
        // Crear el PopupMenu anclado al botón ordButton
        PopupMenu popup = new PopupMenu(this, ordButton);

        // Agregar opciones de ordenación programáticamente
        popup.getMenu().add(0, ORD_ID_ID, 1, R.string.ordenar_parcela_ID);
        popup.getMenu().add(0, ORD_ID_NMAXOCUP, 2, R.string.ordenar_parcela_maxOcup);
        popup.getMenu().add(0, ORD_ID_PRECIOPERSONA, 3, R.string.ordenar_parcela_precioPersona);

        // Manejar las opciones seleccionadas
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case ORD_ID_ID: // Ordenar por ID
                    mParcelaViewModel.getParcelasOrderedById().observe(this, parcelas -> {
                        mAdapter.submitList(parcelas);
                    });
                    return true;
                case ORD_ID_NMAXOCUP: // Ordenar por Ocupantes Máximos
                    mParcelaViewModel.getParcelasOrderedByMaxOccupants().observe(this, parcelas -> {
                        mAdapter.submitList(parcelas);
                    });
                    return true;
                case ORD_ID_PRECIOPERSONA: // Ordenar por Precio
                    mParcelaViewModel.getParcelasOrderedByPrice().observe(this, parcelas -> {
                        mAdapter.submitList(parcelas);
                    });
                    return true;
                default:
                    return false;
            }
        });
        // Mostrar el PopupMenu
        popup.show();
        return true;
    }

    /**
     * Maneja la seleccion de opciones introducidas en la clase "Menu", en el menu de Parcelas.
     * @param item La opcion seleccionada.
     * @return {@code true} si se utliza correctamente, {@code false} en caso contrario.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case CHANGE_ID_PARCELA:
                cambiarReservas();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Cambia a la actividad {@link MenuReservas}.
     */
    private void cambiarReservas() {
        Intent intent = new Intent(this, MenuReservas.class); // que redireccione a MenuReservas
        startActivity(intent);
    }

    /**
     * Maneja las opciones seleccionadas tras pulsar una parcela de la lista de parcelas.
     * @param item La opcion seleccionada.
     * @return {@code true} si se maneja correctamente, {@code false} en caso contrario.
     */
    @Override
    // Metodo para saber que opcion se ha seleccionado
    public boolean onContextItemSelected(MenuItem item) {
        es.unizar.eina.M15_camping.database.Parcela current = mAdapter.getCurrent();
        switch (item.getItemId()) {
            case DELETE_ID:
                Toast.makeText(
                        getApplicationContext(),
                        "Deleting " + current.getTitle(),
                        Toast.LENGTH_LONG).show();
                mParcelaViewModel.delete(current);
                return true;
            case EDIT_ID:
                editParcela(current);
                return true;
        }
        return super.onContextItemSelected(item);
    }

    /**
     * Se lanza la creacion de una nueva parcela.
     */
    private void createParcela() {
        mStartCreateParcela.launch(new Intent(this, ParcelaEdit.class));
    }

    /**
     * Lanzador de actividades para manejar la creacion de una nueva parcela.
     * Llama al metodo {@link ExecuteActivityResultP#process(Bundle, es.unizar.eina.M15_camping.database.Parcela)}
     * para insertar la parcela en el {@link ParcelaViewModel}.
     */
    ActivityResultLauncher<Intent> mStartCreateParcela = newActivityResultLauncher(new ExecuteActivityResultP() {
        @Override
        public void process(Bundle extras, es.unizar.eina.M15_camping.database.Parcela parcela) {
            mParcelaViewModel.insert(parcela);
        }
    });

    /**
     * Metodo auxiliar para registrar un nuevo {@link ActivityResultLauncher}.
     * Metodo que encapsula la logica para manejar los resultados de actividades.
     *
     * @param executable Implementacion de la interfaz {@link ExecuteActivityResultP}
     *                   para procesar los datos devueltos desde una actividad.
     * @return Un {@link ActivityResultLauncher}
     */
     ActivityResultLauncher<Intent> newActivityResultLauncher(ExecuteActivityResultP executable) {
        return registerForActivityResult(
                new StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Bundle extras = result.getData().getExtras();
                        es.unizar.eina.M15_camping.database.Parcela parcela = new es.unizar.eina.M15_camping.database.Parcela(
                                extras.getString(ParcelaEdit.PARCELA_TITLE),
                                extras.getInt(ParcelaEdit.PARCELA_N_MAX_OCUP),
                                extras.getDouble(ParcelaEdit.PARCELA_PRECIO_PERSONA),
                                extras.getString(ParcelaEdit.PARCELA_BODY)
                        );
                        executable.process(extras, parcela);
                    }
                });
    }

    /**
     * Se lanza la edicion de una parcela existente.
     * @param current La parcela seleccionada para editar.
     */
    private void editParcela(es.unizar.eina.M15_camping.database.Parcela current) {
        Intent intent = new Intent(this, ParcelaEdit.class);
        intent.putExtra(ParcelaEdit.PARCELA_TITLE, current.getTitle());
        intent.putExtra(ParcelaEdit.PARCELA_BODY, current.getBody());
        intent.putExtra(ParcelaEdit.PARCELA_ID, current.getId());
        intent.putExtra(ParcelaEdit.PARCELA_N_MAX_OCUP, current.getNMaxOcup());
        intent.putExtra(ParcelaEdit.PARCELA_PRECIO_PERSONA, current.getPrecioPersona());
        mStartUpdateParcela.launch(intent);
    }

    /**
     * Lanzador de actividades para manejar la actualizacion de una parcela existente.
     * Llama al metodo {@link ExecuteActivityResultP#process(Bundle, es.unizar.eina.M15_camping.database.Parcela)}
     * para actualizar la parcela en el {@link ParcelaViewModel}.
     */
    ActivityResultLauncher<Intent> mStartUpdateParcela = newActivityResultLauncher(new ExecuteActivityResultP() {
        @Override
        public void process(Bundle extras, es.unizar.eina.M15_camping.database.Parcela parcela) {
            int id = extras.getInt(ParcelaEdit.PARCELA_ID);
            parcela.setId(id);
            mParcelaViewModel.update(parcela);
        }
    });
    }

    /**
     * Interfaz funcional que se utiliza para procesar los resultados de actividades
     * relacionadas con parcelas.
     */
    interface ExecuteActivityResultP {
        /**
         * Metodo para procesar los datos devueltos desde una actividad (desde MenuParcelas).
         *
         * @param extras  Datos adicionales devueltos como {@link Bundle}.
         * @param parcela Objeto de tipo {@link es.unizar.eina.M15_camping.database.Parcela}
         *                creado o actualizado en la actividad.
         */
        void process(Bundle extras, es.unizar.eina.M15_camping.database.Parcela parcela);
    }
