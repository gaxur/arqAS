package es.unizar.eina.M15_camping.ui;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Locale;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.database.Reserva;

/**
 * Clase ViewHolder para representar y gestionar un elemento de la lista de reservas en un RecyclerView.
 * Implementa {@link View.OnCreateContextMenuListener} para proporcionar un menu en cada elemento.
 */
class ReservaViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
    private final TextView mReservaItemView;

    /**
     * Constructor privado para inicializar el ViewHolder.
     *
     * @param itemView La vista del elemento representada por este ViewHolder.
     */
    private ReservaViewHolder(View itemView) {
        super(itemView);
        mReservaItemView = itemView.findViewById(R.id.textView);
        itemView.setOnCreateContextMenuListener(this);
    }

    /**
     * Vincula un objeto {@link Reserva} al ViewHolder, mostrando su información en la vista.
     *
     * @param reserva El objeto {@link Reserva} que se debe representar en este ViewHolder.
     */
    public void bind(Reserva reserva) {
        // Formatear la fecha para mostrar solo día, mes y año
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String fechaEntradaFormateada = dateFormat.format(reserva.getFechaEntrada());

        // Mostrar el nombre del cliente y la fecha en el formato "Nombre Cliente - Fecha - Precio"
        String text = reserva.getNomCliente() + " - " + fechaEntradaFormateada + " - " + String.format(Locale.getDefault(), "%.2f", reserva.getPrecioTotal());
        mReservaItemView.setText(text);
        itemView.findViewById(R.id.parcela_status).setVisibility(View.GONE);
    }

    /**
     * Crea una nueva instancia de {@link ReservaViewHolder} en el layout correspondiente.
     *
     * @param parent El contenedor donde se añadira la vista modificada.
     * @return Una nueva instancia de {@link ReservaViewHolder}.
     */
    static ReservaViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_item, parent, false);
        return new ReservaViewHolder(view);
    }

    /**
     * Crea un menu para este elemento de la lista.
     * Agrega opciones para editar, eliminar y enviar la reserva correspondiente.
     *
     * @param menu     El menu donde se añadiran las opciones (pulsacion larga de reserva).
     * @param v        La vista asociada al menu contextual.
     * @param menuInfo Informacion adicional sobre el contexto del menu.
     */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        // Añadir opciones de menú contextual
        menu.add(Menu.NONE, MenuReservas.DELETE_ID, Menu.NONE, R.string.delete_reserva);
        menu.add(Menu.NONE, MenuReservas.EDIT_ID, Menu.NONE, R.string.edit_reserva);
        menu.add(Menu.NONE, MenuReservas.SEND_ID, Menu.NONE, R.string.send_reserva_whatsApp);
        menu.add(Menu.NONE, MenuReservas.SEND_ID_2, Menu.NONE, R.string.send_reserva_SMS);
    }
}

