package es.unizar.eina.M15_camping.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.concurrent.Executors;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.database.ParcelaRepository;


/**
 * Actividad para editar o crear una nueva parcela.
 * Permite introducir, validar y guardar los datos de una parcela en la BD.
 */
public class ParcelaEdit extends AppCompatActivity {

    /** Clave para pasar o recibir el titulo de la parcela entre actividades. */
    public static final String PARCELA_TITLE = "title";
    /** Clave para pasar o recibir la descripcion de la parcela entre actividades. */
    public static final String PARCELA_BODY = "body";
    /** Clave para pasar o recibir el ID de la parcela entre actividades. */
    public static final String PARCELA_ID = "id";
    /** Clave para pasar o recibir el número maximo de ocupantes de la parcela entre actividades. */
    public static final String PARCELA_N_MAX_OCUP = "nMaxOcup";
    /** Clave para pasar o recibir el precio por persona de la parcela entre actividades. */
    public static final String PARCELA_PRECIO_PERSONA = "precioPersona";

    private EditText mTitleText;
    private EditText mBodyText;
    private EditText mNMaxOcupText;
    private EditText mPrecioPersonaText;

    private Integer mRowId;

    private ParcelaRepository parcelaRepository;

    /**
     * Inicializa la actividad, configura los campos de entrada y establece los botones de accion.
     *
     * @param savedInstanceState El estado guardado de la instancia anterior, si existe
     * (inicializacion y configuracion).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcelaedit);

        parcelaRepository = new ParcelaRepository(getApplication());

        mTitleText = findViewById(R.id.title);
        mBodyText = findViewById(R.id.body);
        mNMaxOcupText = findViewById(R.id.nMaxOcup);
        mPrecioPersonaText = findViewById(R.id.precio_persona);

        Button mSaveButton = findViewById(R.id.button_save);
        mSaveButton.setOnClickListener(view -> {
            String title = mTitleText.getText().toString();

            // Verificación de campos vacíos
            if (checkEmptyFields()) {
                int id = (mRowId != null) ? mRowId : -1; // -1 para una nueva parcela
                Executors.newSingleThreadExecutor().execute(() -> {
                    if (parcelaRepository.parcelaExists(title, id)) {
                        runOnUiThread(() -> Toast.makeText(this, "Este nombre ya existe.", Toast.LENGTH_LONG).show());
                    } else {
                        saveParcela();
                    }
                });
            }
        });

        populateFields();
    }

    /**
     * Comprueba si todos los campos de entrada obligatorios están llenos y si los valores numéricos son válidos.
     *
     * @return {@code true} si todos los campos están llenos y son válidos; {@code false} en caso contrario.
     */
    private boolean checkEmptyFields() {
        if (TextUtils.isEmpty(mTitleText.getText())) {
            Toast.makeText(this, "Por favor, introduce un nombre para la parcela.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(mNMaxOcupText.getText())) {
            Toast.makeText(this, "Por favor, introduce el número máximo de ocupantes.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!esNumeroEnteroValido(mNMaxOcupText.getText().toString())) {
            Toast.makeText(this, "El número máximo de ocupantes debe ser un número entero válido.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (Integer.parseInt(String.valueOf(mNMaxOcupText.getText())) < 1){
            Toast.makeText(this, "Error: El número máximo de ocupantes debe ser mayor o igual a 1.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(mPrecioPersonaText.getText())) {
            Toast.makeText(this, "Por favor, introduce el precio por persona.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!esNumeroDecimalValido(mPrecioPersonaText.getText().toString())) {
            Toast.makeText(this, "El precio por persona debe ser un número decimal válido.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (Double.parseDouble(String.valueOf(mPrecioPersonaText.getText())) <= 0.0 ){
            Toast.makeText(this, "Error: El precio debe ser mayor a 0.0.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(mBodyText.getText())) {
            Toast.makeText(this, "Por favor, introduce una descripción para la parcela.", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    /**
     * Comprueba si un valor es un número entero válido.
     *
     * @param valor El valor a comprobar.
     * @return {@code true} si el valor es un número entero válido, {@code false} en caso contrario.
     */
    private boolean esNumeroEnteroValido(String valor) {
        try {
            Integer.parseInt(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Comprueba si un valor es un número decimal válido.
     *
     * @param valor El valor a comprobar.
     * @return {@code true} si el valor es un número decimal válido, {@code false} en caso contrario.
     */
    private boolean esNumeroDecimalValido(String valor) {
        try {
            Double.parseDouble(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    /**
     * Guarda los datos de la parcela en la BD y finaliza la actividad.
     * Si se esta editando una parcela existente, incluye su ID en los datos de respuesta.
     */
    private void saveParcela() {
        Intent replyIntent = new Intent();
        replyIntent.putExtra(PARCELA_TITLE, mTitleText.getText().toString());
        replyIntent.putExtra(PARCELA_BODY, mBodyText.getText().toString());
        replyIntent.putExtra(PARCELA_N_MAX_OCUP, Integer.parseInt(mNMaxOcupText.getText().toString()));
        replyIntent.putExtra(PARCELA_PRECIO_PERSONA, Double.parseDouble(mPrecioPersonaText.getText().toString()));

        if (mRowId != null) {
            replyIntent.putExtra(ParcelaEdit.PARCELA_ID, mRowId.intValue());
        }
        setResult(RESULT_OK, replyIntent);
        finish();
    }

    /**
     * Rellena los campos de entrada con los datos de la parcela si se proporcionan.
     * Esto ocurre al editar una parcela existente.
     */
    private void populateFields() {
        mRowId = null;
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            mTitleText.setText(extras.getString(PARCELA_TITLE));
            mBodyText.setText(extras.getString(PARCELA_BODY));
            mNMaxOcupText.setText(String.valueOf(extras.getInt(PARCELA_N_MAX_OCUP)));
            mPrecioPersonaText.setText(String.valueOf(extras.getDouble(PARCELA_PRECIO_PERSONA)));
            mRowId = extras.getInt(PARCELA_ID);
        }
    }
}

