package es.unizar.eina.send;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.Toast;

/** Concrete implementor utilizando la actividad de envío de SMS. No funciona en el emulador si no se ha configurado previamente */
public class SMSImplementor implements SendImplementor {

    /** actividad desde la cual se abrirá la actividad de envío de SMS */
    private Activity sourceActivity;

    /** Constructor
     * @param source actividad desde la cual se abrirá la actividad de envío de SMS
     */
    public SMSImplementor(Activity source){
        setSourceActivity(source);
    }

    /**  Actualiza la actividad desde la cual se abrirá la actividad de envío de SMS */
    public void setSourceActivity(Activity source) {
        sourceActivity = source;
    }

    /**  Recupera la actividad desde la cual se abrirá la actividad de envío de SMS */
    public Activity getSourceActivity(){
        return sourceActivity;
    }

    /**
     * Implementación del método send utilizando la aplicación de envío de SMS
     * @param phone teléfono
     * @param message cuerpo del mensaje
     */
    public void send(String phone, String message) {
        if (phone == null || phone.isEmpty()) {
            Toast.makeText(getSourceActivity(), "Número de teléfono no válido.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (message == null || message.isEmpty()) {
            Toast.makeText(getSourceActivity(), "El mensaje no puede estar vacío.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Uri smsUri = Uri.parse("smsto:" + phone); // Usar "smsto:" en lugar de "sms:"
            Intent sendIntent = new Intent(Intent.ACTION_SENDTO, smsUri);
            sendIntent.putExtra("sms_body", message); // Corregido sin espacios
            getSourceActivity().startActivity(sendIntent);
        } catch (Exception e) {
            Toast.makeText(getSourceActivity(), "Error al intentar enviar el SMS.", Toast.LENGTH_SHORT).show();
        }
    }
}
