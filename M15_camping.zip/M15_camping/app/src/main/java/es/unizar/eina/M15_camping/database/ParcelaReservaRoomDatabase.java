package es.unizar.eina.M15_camping.database;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import androidx.room.TypeConverters;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Clase que define la base de datos Room para la aplicacion.
 * Incluye las entidades {@link Parcela}, {@link Reserva} y {@link ParcelaReservaRel}.
 * Utiliza un {@link TypeConverters} para manejar conversiones personalizadas de datos.
 */
@Database(entities = {Parcela.class, Reserva.class, ParcelaReservaRel.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class ParcelaReservaRoomDatabase extends RoomDatabase {

    /**
     * Metodo abstracto para acceder al DAO de parcelas.
     *
     * @return Instancia de {@link ParcelaDao}.
     */
    public abstract ParcelaDao parcelaDao();

    /**
     * Metodo abstracto para acceder al DAO de reservas.
     *
     * @return Instancia de {@link ReservaDao}.
     */
    public abstract ReservaDao reservaDao();

    /**
     * Metodo abstracto para acceder al DAO de relaciones entre parcelas y reservas.
     *
     * @return Instancia de {@link ParcelaReservaDao}.
     */
    public abstract ParcelaReservaDao parcelaReservaDao();

    /**
     * Instancia unica de la base de datos (Singleton).
     */
    private static volatile ParcelaReservaRoomDatabase INSTANCE;

    /**
     * Numero de hilos disponibles para operaciones de escritura en la base de datos.
     */
    private static final int NUMBER_OF_THREADS = 4;

    /**
     * ExecutorService para ejecutar operaciones de escritura en segundo plano.
     */
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    /**
     * Obtiene la instancia unica de la base de datos.
     * Si no existe, la crea utilizando un patron Singleton.
     *
     * @param context Contexto de la aplicacion.
     * @return Instancia unica de {@link ParcelaReservaRoomDatabase}.
     */
    static ParcelaReservaRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (ParcelaReservaRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    ParcelaReservaRoomDatabase.class, "parcelaReserva_database_finalll")
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * Callback que se ejecuta al crear la base de datos.
     * Permite realizar acciones iniciales, como poblar la base de datos con datos de ejemplo.
     */
    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            // Si deseas mantener los datos a través de reinicios de la aplicación,
            // comenta el siguiente bloque.
            databaseWriteExecutor.execute(() -> {
                // Poblar la base de datos en segundo plano.
                // Si deseas empezar con más datos, simplemente añádelos aquí.
                ParcelaDao dao = INSTANCE.parcelaDao();
                dao.deleteAll();

                // Crear y insertar las parcelas
                Parcela parcela1 = new Parcela("Parcela 1", 5, 15.3, "Parcela cerca del lago");
                long parcelaId1 = dao.insert(parcela1);  // Asegurarse de obtener el ID generado

                Parcela parcela2 = new Parcela("Parcela 2", 2, 10.3, "Parcela con piscina");
                long parcelaId2 = dao.insert(parcela2);  // Asegurarse de obtener el ID generado


                // Inserción de las reservas
                ReservaDao reservaDao = INSTANCE.reservaDao();
                reservaDao.deleteAll();
                ParcelaReservaDao parcelaReservaDao = INSTANCE.parcelaReservaDao();
                parcelaReservaDao.deleteAll();

                try {
                    // Crear fechas válidas con SimpleDateFormat
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date fechaEntrada = dateFormat.parse("2025-01-10");
                    Date fechaSalida = dateFormat.parse("2025-01-14");

                    // Crear y insertar la reserva
                    Reserva reserva = new Reserva(fechaEntrada, fechaSalida, "Alejos", "605391881", 0.0);
                    long reservaId = reservaDao.insert(reserva);  // Asegurarse de obtener el ID generado

                    // Crear la relación Parcela-Reserva para parcela1

                    Log.d("ParcelaReserva", "Antes de insertar relación 1, reservaId: " + reservaId);
                    ParcelaReservaRel rel = new ParcelaReservaRel((int) parcelaId1, (int) reservaId, 2);
                    Log.e("ParcelaReserva", "ParcelaReservaRel 1: " + rel);
                    parcelaReservaDao.insert(rel);

                } catch (Exception e) {
                    Log.e("ParcelaReserva", "Error al insertar reserva o relaciones: " + e.getMessage());
                    e.printStackTrace();
                }

            });
        }
    };

}

