package es.unizar.eina.M15_camping.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;

/**
 * Interfaz que define las operaciones con acceso a datos y consultas para la tabla Reserva.
 * Utiliza las anotaciones de Room para definir las operaciones de acceso a la base de datos.
 */
@Dao
public interface ReservaDao {

    /**
     * Inserta una nueva reserva en la tabla.
     * Si ya existe una reserva con el mismo ID, ignora la operacion.
     *
     * @param reserva El objeto {@link Reserva} que se desea insertar.
     * @return El ID de la fila insertada o -1 si se ignora la operacion.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Reserva reserva);

    /**
     * Actualiza una reserva existente en la tabla.
     *
     * @param reserva El objeto {@link Reserva} que se desea actualizar.
     * @return El numero de filas afectadas por la operacion.
     */
    @Update
    int update(Reserva reserva);

    /**
     * Elimina una reserva existente de la tabla.
     *
     * @param reserva El objeto {@link Reserva} que se desea eliminar.
     * @return El numero de filas afectadas por la operacion.
     */
    @Delete
    int delete(Reserva reserva);

    /**
     * Elimina todas las reservas de la tabla.
     */
    @Query("DELETE FROM reserva")
    void deleteAll();

    /**
     * Recupera todas las reservas ordenadas por fecha de entrada (de menor a mayor).
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    @Query("SELECT * FROM reserva ORDER BY fechaEntrada ASC")
    LiveData<List<Reserva>> getReservasOrderedByFechaEntrada();

    /**
     * Recupera todas las reservas ordenadas por nombre del cliente (alfabeticamente).
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    @Query("SELECT * FROM reserva ORDER BY nomCliente ASC")
    LiveData<List<Reserva>> getReservasOrderedByNomCliente();

    /**
     * Recupera todas las reservas ordenadas por numero del cliente.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    @Query("SELECT * FROM reserva ORDER BY numCliente ASC")
    LiveData<List<Reserva>> getReservasOrderedByNumCliente();

    /**
     * Elimina todas las parcelas asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva de la cual se eliminarán las parcelas.
     */
    @Query("DELETE FROM ParcelaReservaRel WHERE reservaId = :reservaId")
    void deleteParcelaReserva(int reservaId);

    /**
     * Elimina una reserva específica por su ID.
     *
     * @param reservaId El ID de la reserva a eliminar.
     */
    @Query("DELETE FROM Reserva WHERE id = :reservaId")
    void deleteReservaById(int reservaId);

    /**
     * Obtiene la fecha de entrada de una reserva específica.
     *
     * @param reservaId ID de la reserva.
     * @return La fecha de entrada en milisegundos.
     */
    @Query("SELECT fechaEntrada FROM Reserva WHERE id = :reservaId")
    long getFechaEntrada(int reservaId);

    /**
     * Obtiene la fecha de salida de una reserva específica.
     *
     * @param reservaId ID de la reserva.
     * @return La fecha de salida en milisegundos.
     */
    @Query("SELECT fechaSalida FROM Reserva WHERE id = :reservaId")
    long getFechaSalida(int reservaId);

    /**
     * Actualiza el precio total de una reserva específica.
     *
     * @param reservaId ID de la reserva.
     * @param precioTotal Nuevo precio total para la reserva.
     */
    @Query("UPDATE Reserva SET precioTotal = :precioTotal WHERE id = :reservaId")
    void actualizarPrecioTotal(int reservaId, double precioTotal);

    /**
     * Obtiene todas las parcelas asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva.
     * @return Lista de parcelas asociadas a la reserva.
     */
    @Query("SELECT p.* FROM Parcela p INNER JOIN ParcelaReservaRel rp ON p.id = rp.parcelaid WHERE rp.reservaid = :reservaId")
    List<Parcela> getParcelasPorReserva(int reservaId);

    /**
     * Obtiene una reserva específica de la base de datos a partir de su identificador único {@code reservaId}.
     * La consulta busca la reserva cuyo {@code id} coincida con el valor proporcionado, y se limita a
     * una sola coincidencia debido al uso de {@code LIMIT 1}.
     *
     * @param reservaId El identificador único de la reserva que se desea obtener.
     * @return Un objeto {@link Reserva} que representa la reserva encontrada, o {@code null} si no
     *         se encuentra ninguna reserva con el {@code reservaId} proporcionado.
     */
    @Query("SELECT * FROM reserva WHERE id = :reservaId LIMIT 1")
    Reserva getReservaById(int reservaId);

    /**
     * Obtiene una reserva de la base de datos por el nombre del cliente.
     * Esta consulta busca una reserva utilizando el nombre del cliente como filtro.
     *
     * @param nombreCliente El nombre del cliente que se desea buscar.
     * @return La reserva asociada al nombre de cliente especificado, o null si no se encuentra.
     */
    @Query("SELECT * FROM reserva WHERE nomCliente = :nombreCliente LIMIT 1")
    Reserva getReservaByCliente(String nombreCliente);

    /**
     * Obtiene el número de registros de reservas con un ID específico.
     * Este método se utiliza para comprobar si una reserva con un ID dado existe en la base de datos.
     *
     * @param reservaId El ID de la reserva que se desea verificar.
     * @return El número de reservas que coinciden con el ID proporcionado.
     *         Devuelve 0 si no existe ninguna reserva con ese ID.
     */
    @Query("SELECT COUNT(*) FROM Reserva WHERE id = :reservaId")
    int getCountById(int reservaId);


}
