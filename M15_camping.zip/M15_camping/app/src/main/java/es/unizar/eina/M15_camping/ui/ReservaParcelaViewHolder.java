package es.unizar.eina.M15_camping.ui;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.database.Parcela;

/**
 * ViewHolder específico para la pantalla de "ReservaEditParcela".
 * Este ViewHolder no incluye menús contextuales.
 */
public class ReservaParcelaViewHolder extends RecyclerView.ViewHolder {
    private final TextView mParcelaItemView;
    private final TextView parcelaStatus;

    /**
     * Constructor para inicializar el ViewHolder.
     *
     * @param itemView La vista del elemento representada por este ViewHolder.
     */
    public ReservaParcelaViewHolder(View itemView) {
        super(itemView);
        mParcelaItemView = itemView.findViewById(R.id.textView);
        parcelaStatus = itemView.findViewById(R.id.parcela_status);
    }

    /**
     * Vincula un objeto {@link Parcela} al ViewHolder.
     *
     * @param parcela El objeto {@link Parcela} que se debe mostrar.
     */
    public void bind(Parcela parcela) {
        // Mostrar el título y el ID en el formato "Nombre (ID)"
        String text = parcela.getTitle();
        mParcelaItemView.setText(text);
        parcelaStatus.setVisibility(View.VISIBLE);
    }

    /**
     * Crea una nueva instancia de {@link ReservaParcelaViewHolder}.
     *
     * @param parent El contenedor donde se añadirá la vista modificada.
     * @return Una nueva instancia de {@link ReservaParcelaViewHolder}.
     */
    static ReservaParcelaViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_item, parent, false);
        return new ReservaParcelaViewHolder(view);
    }

    /**
     * Actualiza el texto y el color del estado de una parcela en la interfaz de usuario.
     *
     * Este método se utiliza para cambiar el texto que describe el estado de la parcela
     * y el color de dicho texto para reflejar visualmente su estado en la aplicación.
     *
     * @param statusText El nuevo texto que describe el estado de la parcela.
     * @param color El color que se debe aplicar al texto del estado.
     *              Este valor debe ser un color válido, como un recurso de color o un valor RGB.
     */
    public void updateStatus(String statusText, int color) {
        parcelaStatus.setText(statusText);
        parcelaStatus.setTextColor(color);
    }
}
