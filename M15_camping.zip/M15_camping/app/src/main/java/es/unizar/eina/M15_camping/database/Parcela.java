package es.unizar.eina.M15_camping.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/** Clase anotada como entidad que representa una nota y que consta de titulo, cuerpo, nMaxOcup y precioPersona */
@Entity(tableName = "parcela")
public class Parcela {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @NonNull
    @ColumnInfo(name = "title")
    private String title;

    @NonNull
    @ColumnInfo (name = "nMaxOcup")
    private Integer nMaxOcup;

    @NonNull
    @ColumnInfo (name = "precioPersona")
    private Double precioPersona;

    @NonNull
    @ColumnInfo(name = "body")
    private String body;

    public Parcela(@NonNull String title, @NonNull Integer nMaxOcup, @NonNull Double precioPersona, @NonNull String body) {
        this.title = title; // nombre
        this.nMaxOcup = nMaxOcup;
        this.precioPersona = precioPersona;
        this.body = body; // descripcion
    }

    /** Devuelve el identificador de la parcela */
    public int getId() { return this.id; }

    /** Permite actualizar el identificador de una parcela */
    public void setId(int id) { this.id = id; }

    /** Devuelve el nombre de la parcela */
    public String getTitle() { return this.title; }

    /** Permite actualizar el nombre de una parcela */
    public void setTitle(String title) { this.title = title; }

    /** Devuelve el numero maximo de personas de la parcela */
    public Integer getNMaxOcup() { return this.nMaxOcup; }

    /** Permite actualizar el numero maximo de personas de una parcela */
    public void setNMaxOcup(Integer nMaxOcup) { this.nMaxOcup = nMaxOcup; }

    /** Devuelve el precio por persona de la parcela */
    public Double getPrecioPersona() { return this.precioPersona; }

    /** Permite actualizar el precio por persona de una parcela */
    public void setPrecioPersona(Double precioPersona) { this.precioPersona = precioPersona; }

    /** Devuelve la descripcion de la parcela */
    public String getBody() { return this.body; }

    /** Permite actualizar la descripcion de una parcela */
    public void setBody(String body) { this.body = body; }
}
