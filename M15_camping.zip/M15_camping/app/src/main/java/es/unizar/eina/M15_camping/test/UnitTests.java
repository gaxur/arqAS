package es.unizar.eina.M15_camping.test;

import static java.lang.Thread.sleep;

import android.app.Application;
import android.content.Context;
import android.icu.text.LocaleDisplayNames;
import android.util.Log;

import androidx.lifecycle.Observer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import es.unizar.eina.M15_camping.database.Parcela;
import es.unizar.eina.M15_camping.database.ParcelaRepository;
import es.unizar.eina.M15_camping.database.Reserva;
import es.unizar.eina.M15_camping.database.ReservaRepository;
import es.unizar.eina.M15_camping.ui.ParcelaViewModel;

/**
 * Clase encargada de ejecutar los tests para la validación de las operaciones sobre las parcelas.
 */
public class UnitTests {

    // Contexto de la aplicación
    private final Application application;

    /**
     * Constructor de la clase UnitTests.
     *
     * @param application Contexto de la aplicación para acceder a los repositorios.
     */
    public UnitTests(Application application) {
        this.application = application;
    }

    /**
     * Limpia la base de datos eliminando todas las parcelas, reservas y sus relaciones asociadas.
     * Este método utiliza un `ExecutorService` para ejecutar las operaciones de borrado en un hilo separado.
     *
     * @param parcelaRepository   El repositorio que gestiona las operaciones de la entidad {@link Parcela}.
     * @param reservaRepository   El repositorio que gestiona las operaciones de la entidad {@link Reserva}
     *                            y las relaciones entre reservas y parcelas.
     */
    private void clearDatabase(ParcelaRepository parcelaRepository, ReservaRepository reservaRepository) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            parcelaRepository.deleteAllParcelas();
            reservaRepository.deleteAllReservas();
            reservaRepository.deleteAllParcelaReservaRelations();
        });
        executor.shutdown();
    }

    /**
     * Ejecuta los tests para la validación de la creación, modificación y eliminación de parcelas.
     *
     * @return Lista con los resultados de los tests.
     */
    public List<String> ejecutarTests(String parcelasOreservas) {
        // Lista para almacenar los resultados de los tests
        List<String> results = new ArrayList<>();

        // Inicializamos el repositorio de parcelas
        ParcelaRepository parcelaRepository = new ParcelaRepository((Application) application);
        ReservaRepository reservaRepository = new ReservaRepository((Application) application);
        ParcelaViewModel parcelaViewModel = new ParcelaViewModel((Application) application);

        // Creamos un ExecutorService para ejecutar las operaciones de base de datos en un hilo separado
        ExecutorService executorService = Executors.newSingleThreadExecutor();

        clearDatabase(parcelaRepository, reservaRepository);

        try {
            if (parcelasOreservas == "parcelas"){
                // Test 1: Crear parcela con nombre válido
                // Se crea una parcela con nombre "hola", 10 max ocupantes y precio de 10.0
                Parcela parcela1 = new Parcela("prueba", 10, 10.0, "parcela con agua");
                Future<Long> futureParcela1 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela1);
                    }
                });
                long parcelaId1 = futureParcela1.get();
                parcela1.setId((int) parcelaId1); // Actualiza el ID en el objeto después de la inserción
                Log.d("Test1", "Parcela actualizada con ID: " + parcela1.getId());

                // Verificamos si la parcela se ha insertado correctamente
                if (parcelaId1 != -1) {
                    results.add("Test 1 (Crear Parcela): OK");
                } else {
                    results.add("Test 1 (Crear Parcela): ERROR");
                }

                // Test 2: Intentar crear parcela con nombre nulo
                // Intentamos crear una parcela con el nombre nulo
                Parcela parcela2 = new Parcela(null, 10, 10.0, "parcela con agua");
                Future<Long> futureParcela2 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela2);
                    }
                });
                // Verificamos que la creación con nombre nulo debería fallar
                long parcelaId2 = futureParcela2.get();
                if (parcelaId2 == -1) {
                    results.add("Test 2 (Crear Parcela con nombre nulo): OK");
                } else {
                    results.add("Test 2 (Crear Parcela con nombre nulo): ERROR");
                }

                // Test 3: Intentar crear parcela con nombre no único
                // Intentamos crear una parcela con el mismo nombre que la anterior
                Parcela parcela3 = new Parcela("prueba", 10, 10.0, "parcela con agua");
                Future<Long> futureParcela3 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela3);
                    }
                });
                // Verificamos que la creación con nombre duplicado debería fallar
                long parcelaId3 = futureParcela3.get();
                if (parcelaId3 == -1) {
                    results.add("Test 3 (Crear Parcela con nombre no único): OK");
                } else {
                    results.add("Test 3 (Crear Parcela con nombre no único): ERROR");
                }

                // Test 4: Crear parcela con nMaxOcupantes igual a 0
                // Intentamos crear una parcela con 0 ocupantes
                Parcela parcela4 = new Parcela("a", 0, 10.0, "parcela con agua");
                Future<Long> futureParcela4 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela4);
                    }
                });
                // Verificamos que la creación con nMaxOcupantes igual a 0 debería fallar
                long parcelaId4 = futureParcela4.get();
                if (parcelaId4 == -1) {
                    results.add("Test 4 (Crear Parcela con nMaxOcupantes = 0): OK");
                } else {
                    results.add("Test 4 (Crear Parcela con nMaxOcupantes = 0): ERROR");
                }

                // Test 5: Crear parcela con nMaxOcupantes igual a 0a
                // Intentamos crear una parcela con nMaxOcupantes igual a 0a, lo cual no deja pq esta predifinido "double"
                try {
                    // Intentamos convertir un valor inválido "0a" a un número entero
                    int nMaxOcupantes5 = Integer.parseInt("0a");
                    Parcela parcela5 = new Parcela("b", nMaxOcupantes5, 10.0, "parcela con agua");

                    Future<Long> futureParcela5 = executorService.submit(() -> parcelaRepository.insert(parcela5));
                    long parcelaId5 = futureParcela5.get();

                    // Si se permite la inserción, el test debe fallar
                    if (parcelaId5 == -1) {
                        results.add("Test 5 (Crear Parcela con nMaxOcupantes = 0a): OK - Parcela no creada por valor inválido");
                    } else {
                        results.add("Test 5 (Crear Parcela con nMaxOcupantes = 0a): ERROR - Parcela creada con valor inválido");
                    }
                } catch (NumberFormatException e) {
                    // Capturamos la excepción y evitamos que la ejecución se detenga
                    results.add("Test 5 (Crear Parcela con nMaxOcupantes = 0a): OK - Número inválido detectado correctamente");
                } catch (Exception ex) {
                    results.add("Test 5 (Crear Parcela con nMaxOcupantes = 0a): ERROR - Excepción inesperada: " + ex.getMessage());
                }

                // Test 6: Crear parcela con nMaxOcupantes igual a nulo
                // Intentamos crear una parcela con nMaxOcupantes igual a nulo
                Parcela parcela6 = new Parcela("c", null, 10.0, "parcela con agua");
                Future <Long> futureParcela6 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela6);
                    }
                });
                // Verificamos que la creación con MaxOcupantes igual a nulo debería fallar
                long parcelaId6 = futureParcela6.get();
                if (parcelaId6 == -1) {
                    results.add("Test 6 (Crear Parcela con nMaxOcupantes es nulo): OK");
                } else {
                    results.add("Test 6 (Crear Parcela con nMaxOcupantes es nulo): ERROR");
                }

                // Test 7: Crear parcela con precioPersona igual a 0.0
                // Intentamos crear una parcela con el precioPersona igual a 0.0
                Parcela parcela7 = new Parcela("d", 10, 0.0, "parcela con agua");
                Future <Long> futureParcela7 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela7);
                    }
                });
                // Verificamos que la creación con precioPersona igual a 0.0
                long parcelaId7 = futureParcela7.get();
                if (parcelaId7 == -1) {
                    results.add("Test 7 (Crear Parcela con precioPersona = 0.0): OK");
                } else {
                    results.add("Test 7 (Crear Parcela con precioPersona = 0.0): ERROR");
                }

                // Test 8: Crear parcela con precioPersona igual a "a"
                // Intentamos crear una parcela con la descripción nula
                try {
                    // Intentamos convertir un valor inválido "a" a un número double
                    double precioPersona8 = Double.parseDouble("a");

                    // Si no lanza excepción (lo cual no debería ocurrir), intentamos crear la parcela
                    Parcela parcela8 = new Parcela("e", 10, precioPersona8, "parcela con agua");
                    Future<Long> futureParcela8 = executorService.submit(() -> parcelaRepository.insert(parcela8));
                    long parcelaId8 = futureParcela8.get();

                    // Verificamos si la parcela se creó (lo cual sería un error)
                    if (parcelaId8 == -1) {
                        results.add("Test 8 (Crear Parcela con precioPersona igual a \"a\"): OK - Parcela no creada por valor inválido");
                    } else {
                        results.add("Test 8 (Crear Parcela con precioPersona igual a \"a\"): ERROR - Parcela creada con valor inválido");
                    }
                } catch (NumberFormatException e) {
                    // Capturamos la excepción y manejamos el caso correctamente
                    results.add("Test 8 (Crear Parcela con precioPersona igual a \"a\"): OK - Número inválido detectado correctamente");
                } catch (Exception ex) {
                    // Capturamos cualquier otra excepción inesperada
                    results.add("Test 8 (Crear Parcela con precioPersona igual a \"a\"): ERROR - Excepción inesperada: " + ex.getMessage());
                }

                // Test 9: Crear parcela con precioPersona es nulo
                // Intentamos crear una parcela con precioPersona nulo
                Parcela parcela9 = new Parcela("f", 10, null, "parcela con agua");
                Future<Long> futureParcela9 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela9);
                    }
                });
                // Verificamos que la creación con precioPersona igual a "a" debería fallar
                long parcelaId9 = futureParcela9.get();
                if (parcelaId9 == -1) {
                    results.add("Test 9 (Crear Parcela con precioPersona nulo): OK");
                } else {
                    results.add("Test 9 (Crear Parcela con precioPersona nulo): ERROR");
                }

                // Test 10: Crear parcela con descripción nula
                // Intentamos crear una parcela con la descripción nula
                Parcela parcela10 = new Parcela("g", 10, 10.0, null);
                Future<Long> futureParcela10 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return parcelaRepository.insert(parcela10);
                    }
                });
                // Verificamos que la creación con descripción nula debería fallar
                long parcelaId10 = futureParcela10.get();
                if (parcelaId10 == -1) {
                    results.add("Test 10 (Crear Parcela con descripción nula): OK");
                } else {
                    results.add("Test 10 (Crear Parcela con descripción nula): ERROR");
                }

                // Test 11: Eliminar parcela existente
                // Eliminamos la parcela creada en el Test 1
                Integer deletedParcela11 = -1;
                if(parcelaId1 != -1){
                    Future<Integer> futureParcela11 = executorService.submit(new Callable<Integer>() {
                        @Override
                        public Integer call() {
                            return parcelaRepository.delete(parcela1);
                        }
                    });
                    deletedParcela11 = futureParcela11.get();
                }
                if (deletedParcela11 != -1) {
                    results.add("Test 11 (Eliminar Parcela Existente): OK");
                } else {
                    results.add("Test 11 (Eliminar Parcelan Existente): ERROR");
                }

                // Test 12: Eliminar parcela con nombre nulo
                Parcela parcela12 = new Parcela(null, 10,10.0,"parcela con agua");
                int deletedParcela12 = parcelaRepository.delete(parcela12);
                if (deletedParcela12 != -1) {
                    results.add("Test 12 (Eliminar Parcela con nombre nulo): OK");
                } else {
                    results.add("Test 12 (Eliminar Parcela con nombre nulo): ERROR");
                }

                // Test 13: Eliminar parcela con nMaxOcupantes nulo
                Parcela parcela13 = new Parcela("c", null,10.0,"parcela con agua");
                int deletedParcela13 = parcelaRepository.delete(parcela13);
                if (deletedParcela13 != -1) {
                    results.add("Test 13 (Eliminar Parcela con nMaxOcupantes nulo): OK");
                } else {
                    results.add("Test 13 (Eliminar Parcela con nMaxOcupantes nulo): ERROR");
                }

                // Test 14: Eliminar parcela con precioPersona nulo
                Parcela parcela14 = new Parcela("f", 10,null,"parcela con agua");
                int deletedParcela14 = parcelaRepository.delete(parcela14);
                if (deletedParcela14 != -1) {
                    results.add("Test 14 (Eliminar Parcela con precioPersona nulo): OK");
                } else {
                    results.add("Test 14 (Eliminar Parcela con precioPersona nulo): ERROR");
                }

                // Test 15: Eliminar parcela con descripcion nulo
                Parcela parcela15 = new Parcela("g", 10,10.0,null);
                int deletedParcela15 = parcelaRepository.delete(parcela15);
                if (deletedParcela15 != -1) {
                    results.add("Test 15 (Eliminar Parcela con descripcion nula): OK");
                } else {
                    results.add("Test 15 (Eliminar Parcela con descripcion nula): ERROR");
                }

                // Test 16: Modificar parcela con nombre válido
                Parcela parcela16 = new Parcela("parcelaModificar", 10, 15.0, "parcela con piscina");
                Future<Long> futureParcela16 = executorService.submit(() -> parcelaRepository.insert(parcela16));
                long parcelaId16 = futureParcela16.get();
                parcela16.setId((int) parcelaId16);

                if (parcelaId16 != -1) {
                    parcela16.setTitle("parcelaModificada");
                    Future<Integer> futureUpdate16 = executorService.submit(() -> parcelaRepository.update(parcela16));
                    int updatedRows16 = futureUpdate16.get();

                    Parcela updatedParcela = parcelaRepository.getParcelaById((int) parcelaId16);
                    if (updatedRows16 > 0 && "parcelaModificada".equals(updatedParcela.getTitle())) {
                        results.add("Test 16 (Modificar Parcela con nombre válido): OK - Actualización exitosa");
                    } else {
                        results.add("Test 16 (Modificar Parcela con nombre válido): ERROR - Actualización fallida");
                    }
                }

                // Test 17: Modificar parcela con nombre nulo
                Parcela parcela17 = new Parcela("parcelaNombreNulo", 8, 12.0, "parcela con barbacoa");
                Future<Long> futureParcela17 = executorService.submit(() -> parcelaRepository.insert(parcela17));
                long parcelaId17 = futureParcela17.get();
                parcela17.setId((int) parcelaId17);

                if (parcelaId17 != -1) {
                    // Modificar el título a null para comprobar el test
                    parcela17.setTitle(null);
                    Future<Integer> futureUpdate17 = executorService.submit(() -> parcelaRepository.update(parcela17));
                    int updatedRows17 = futureUpdate17.get();

                    if (updatedRows17 == -1) {
                        results.add("Test 17 (Modificar Parcela con nombre nulo): OK - Actualización bloqueada por validación");
                    } else {
                        results.add("Test 17 (Modificar Parcela con nombre nulo): ERROR - Se permitió actualizar con nombre nulo");
                    }
                }

                // Test 18: Modificar parcela con nMaxOcupantes igual a 0
                Parcela parcela18 = new Parcela("parcelaMaxOcup0", 10, 10.0, "parcela con sombra");
                Future<Long> futureParcela18 = executorService.submit(() -> parcelaRepository.insert(parcela18));
                long parcelaId18 = futureParcela18.get();
                parcela18.setId((int) parcelaId18);

                if (parcelaId18 != -1) {
                    parcela18.setNMaxOcup(0);
                    Future<Integer> futureUpdate18 = executorService.submit(() -> parcelaRepository.update(parcela18));
                    int updatedRows18 = futureUpdate18.get();

                    if (updatedRows18 == -1) {
                        results.add("Test 18 (Modificar Parcela con nMaxOcupantes = 0): OK - Actualización bloqueada por validación");
                    } else {
                        results.add("Test 18 (Modificar Parcela con nMaxOcupantes = 0): ERROR - Se permitió actualizar con nMaxOcupantes = 0");
                    }
                }

                // Test 19: Modificar parcela con precioPersona igual a 0.0
                Parcela parcela19 = new Parcela("parcelaPrecio0", 5, 15.0, "parcela con césped");
                Future<Long> futureParcela19 = executorService.submit(() -> parcelaRepository.insert(parcela19));
                long parcelaId19 = futureParcela19.get();
                parcela19.setId((int) parcelaId19);

                if (parcelaId19 != -1) {
                    parcela19.setPrecioPersona(0.0);
                    Future<Integer> futureUpdate19 = executorService.submit(() -> parcelaRepository.update(parcela19));
                    int updatedRows19 = futureUpdate19.get();

                    if (updatedRows19 == -1) {
                        results.add("Test 19 (Modificar Parcela con precioPersona = 0.0): OK - Actualización bloqueada por validación");
                    } else {
                        results.add("Test 19 (Modificar Parcela con precioPersona = 0.0): ERROR - Se permitió actualizar con precioPersona = 0.0");
                    }
                }

                // Test 20: Modificar parcela con descripción nula
                Parcela parcela20 = new Parcela("parcelaDescripcionNula", 8, 12.0, "parcela con vistas");
                Future<Long> futureParcela20 = executorService.submit(() -> parcelaRepository.insert(parcela20));
                long parcelaId20 = futureParcela20.get();
                parcela20.setId((int) parcelaId20);

                if (parcelaId20 != -1) {
                    parcela20.setBody(null);
                    Future<Integer> futureUpdate20 = executorService.submit(() -> parcelaRepository.update(parcela20));
                    int updatedRows20 = futureUpdate20.get();

                    if (updatedRows20 == -1) {
                        results.add("Test 20 (Modificar Parcela con descripción nula): OK - Actualización bloqueada por validación");
                    } else {
                        results.add("Test 20 (Modificar Parcela con descripción nula): ERROR - Se permitió actualizar con descripción nula");
                    }
                }
            }
            else{
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

                /*
                 * Test 1: Crear reserva valida
                 */
                Date fechaEntrada = dateFormat.parse("2025-02-23");
                Date fechaSalida = dateFormat.parse("2025-02-24");
                assert fechaSalida != null;
                assert fechaEntrada != null;

                // Insertar la reserva
                Reserva reserva1 = new Reserva(fechaEntrada, fechaSalida, "Marcos", "603303030", 0.0);
                Future<Long> futureReserva1 = executorService.submit(() -> reservaRepository.insert(reserva1));
                long reservaId1 = futureReserva1.get();
                reserva1.setId((int) reservaId1); // Actualiza el ID en el objeto después de la inserción

                if (reservaId1 != -1) {
                    // Insertar la parcela
                    Parcela parcela1 = new Parcela("pruebaReserva", 10, 10.0, "parcela con agua");
                    Future<Long> futureParcela1 = executorService.submit(() -> parcelaRepository.insert(parcela1));
                    long parcelaId1 = futureParcela1.get();
                    parcela1.setId((int) parcelaId1); // Actualiza el ID en el objeto después de la inserción

                    // Envolver la llamada a insertOrUpdateParcelaReservaRel en un Future
                    reservaRepository.insertOrUpdateParcelaReservaRelAsync((int) reservaId1, (int) parcelaId1, 1).get();

                    // Validar si la relación se insertó correctamente
                    int parcelasAsociadas = reservaRepository.getParcelasCountByReservaId((int) reservaId1);
                    if (parcelasAsociadas > 0) {
                        results.add("Test 1 (Crear Reserva Valida): OK");
                    } else {
                        results.add("Test 1 (Crear Reserva Valida): ERROR");
                    }
                } else {
                    results.add("Test 1 (Crear Reserva Valida): ERROR");
                }

                /*
                 * Test 2: Crear reserva valida con numOcupantes 0 (ya hay una parcela asociada que no es esta)
                 */
                if (reservaId1 != -1) {
                    Parcela parcela2 = new Parcela("pruebaReserva2", 10, 10.0, "parcela con agua");
                    Future<Long> futureParcela2 = executorService.submit(new Callable<Long>() {
                        @Override
                        public Long call() {
                            return parcelaRepository.insert(parcela2);
                        }
                    });
                    long parcelaId2 = futureParcela2.get();
                    parcela2.setId((int) parcelaId2); // Actualiza el ID en el objeto después de la inserción
                    reservaRepository.insertOrUpdateParcelaReservaRelAsync((int) reservaId1, (int) parcelaId2, 0).get();

                    // Validar si la relación se insertó correctamente
                    int parcelasAsociadas = reservaRepository.getParcelasCountByReservaId((int) reservaId1);
                    if (parcelasAsociadas > 0) {
                        results.add("Test 1 (Crear Reserva Valida): OK");
                    } else {
                        results.add("Test 1 (Crear Reserva Valida): ERROR");
                    }
                } else {
                    results.add("Test 2 (Crear Reserva Valida con numOcupantes 0): ERROR");
                }

                /*
                 * Test 3: Crear reserva Formato invalido de fechas
                 * Debido a que hace falta ponerlo en fomato Date , debera dar error
                 * Se prueba el formato erroneo en las dos fechas para no repetir tests
                 */
                try {
                    // Intentamos usar un formato incorrecto para las fechas
                    Date fechaEntrada3 = new SimpleDateFormat("dd-MM-yyyy").parse("13-02-2024"); // Formato incorrecto
                    Date fechaSalida3 = new SimpleDateFormat("dd-MM-yyyy").parse("14-02-2024"); // Formato incorrecto
                    assert fechaSalida3 != null;
                    assert fechaEntrada3 != null;

                    Reserva reserva3 = new Reserva(fechaEntrada3, fechaSalida3, "Marcos", "603303030", 0.0);
                    Future<Long> futureReserva3 = executorService.submit(() -> reservaRepository.insert(reserva3));
                    long reservaId3 = futureReserva3.get();

                    if (reservaId3 != -1) {
                        // Si la reserva se crea, intentamos asociar una parcela, lo cual no debería pasar
                        Parcela parcela3 = new Parcela("pruebaReserva3", 10, 10.0, "parcela con agua");
                        Future<Long> futureParcela3 = executorService.submit(() -> parcelaRepository.insert(parcela3));
                        long parcelaId3 = futureParcela3.get();
                        reservaRepository.insertOrUpdateParcelaReservaRel((int) reservaId3, (int) parcelaId3, 1);
                        results.add("Test 3 (Crear Reserva Formato Invalido): ERROR - Reserva creada con fechas inválidas");
                    } else {
                        results.add("Test 3 (Crear Reserva Formato Invalido): OK - Reserva no creada por fechas inválidas");
                    }
                } catch (ParseException e) {
                    results.add("Test 3 (Crear Reserva Formato Invalido): OK - Error al parsear fechas inválidas");
                }

                /*
                * Test 4: fechaEntrada anterior a fecha actual
                */

                try {
                    // Crear fechas válidas en el formato esperado
                    Date fechaEntrada4 = dateFormat.parse("2024-02-23"); // Cambia esta fecha según el día actual para forzar fallo
                    Date fechaSalida4 = dateFormat.parse("2025-02-24");
                    assert fechaEntrada4 != null;
                    assert fechaSalida4 != null;

                    Reserva reserva4 = new Reserva(fechaEntrada4, fechaSalida4, "Marcos", "603303030", 0.0);
                    Future<Long> futureReserva4 = executorService.submit(() -> reservaRepository.insert(reserva4));
                    long reservaId4 = futureReserva4.get();

                    if (reservaId4 != -1) {
                        // Si la reserva se crea, intentamos asociar una parcela, lo cual no debería pasar
                        Parcela parcela4 = new Parcela("pruebaReserva4", 10, 10.0, "parcela con agua");
                        Future<Long> futureParcela4 = executorService.submit(() -> parcelaRepository.insert(parcela4));
                        long parcelaId4 = futureParcela4.get();
                        reservaRepository.insertOrUpdateParcelaReservaRel((int) reservaId4, (int) parcelaId4, 1);
                        results.add("Test 4 (Crear Reserva Fecha Entrada anterior a Fecha Actual): ERROR - Reserva creada con fecha de entrada inválida");
                    } else {
                        results.add("Test 4 (Crear Reserva Fecha Entrada anterior a Fecha Actual): OK - Reserva no creada");
                    }
                } catch (ParseException e) {
                    results.add("Test 4 (Crear Reserva Fecha Entrada anterior a Fecha Actual): OK - Error en el formato de fecha");
                }

                // Test 5: Crear reserva con fechaEntrada >= fechaSalida
                try {
                    // Fechas donde la fecha de entrada es posterior o igual a la fecha de salida
                    Date fechaEntrada5 = dateFormat.parse("2025-02-25"); // Fecha entrada
                    Date fechaSalida5 = dateFormat.parse("2025-02-24");  // Fecha salida

                    assert fechaEntrada5 != null;
                    assert fechaSalida5 != null;

                    Reserva reserva5 = new Reserva(fechaEntrada5, fechaSalida5, "Marcos", "603303030", 0.0);
                    Future<Long> futureReserva5 = executorService.submit(() -> reservaRepository.insert(reserva5));
                    long reservaId5 = futureReserva5.get();

                    if (reservaId5 != -1) {
                        // Si la reserva se crea, intentamos asociar una parcela, lo cual no debería pasar
                        Parcela parcela5 = new Parcela("pruebaReserva5", 10, 10.0, "parcela con agua");
                        Future<Long> futureParcela5 = executorService.submit(() -> parcelaRepository.insert(parcela5));
                        long parcelaId5 = futureParcela5.get();
                        reservaRepository.insertOrUpdateParcelaReservaRel((int) reservaId5, (int) parcelaId5, 1);
                        results.add("Test 5 (Crear Reserva Fecha Entrada posterior a Fecha Salida): ERROR - Reserva creada con fechas inválidas");
                    } else {
                        results.add("Test 5 (Crear Reserva Fecha Entrada posterior a Fecha Salida): OK - Reserva no creada");
                    }
                } catch (ParseException e) {
                    results.add("Test 5 (Crear Reserva Fecha Entrada posterior a Fecha Salida): OK - Error en el formato de fecha");
                }

                /*
                 * Test 6: fechaEntrada,fechaSalida,nomCliente,numcliente null (en numOcupantes no deja null)
                 */

                Reserva reserva6 = new Reserva(null,null, null,null,null);
                Future<Long> futureReserva6 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return reservaRepository.insert(reserva6);
                    }
                });
                long reservaId6 = futureReserva6.get();
                // Verificamos si la parcela se ha insertado correctamente
                if (reservaId6 != -1) {
                    Parcela parcela6 = new Parcela("pruebaReserva6", 10, 10.0, "parcela con agua");
                    Future<Long> futureParcela6 = executorService.submit(new Callable<Long>() {
                        @Override
                        public Long call() {
                            return parcelaRepository.insert(parcela6);
                        }
                    });
                    long parcelaId6 = futureParcela6.get();
                    reservaRepository.insertOrUpdateParcelaReservaRel((int) reservaId6, (int) parcelaId6, 1);
                    results.add("Test 6 (Crear Reserva Atributos Null): ERROR");
                } else {
                    results.add("Test 6 (Crear Reserva Atributos Null): OK");
                }

                /*
                 * Test 7: Numcliente.length != 9 y Numcliente no solo contiene numeros (se juntan para no ser redundante)
                 */
                Date fechaEntrada7 = dateFormat.parse("2025-02-24");
                Date fechaSalida7 = dateFormat.parse("2025-02-25");
                assert fechaSalida7 != null;
                assert fechaEntrada7 != null;
                Reserva reserva7 = new Reserva(fechaEntrada7,fechaSalida7, "Marcos","603a",0.0);
                Future<Long> futureReserva7 = executorService.submit(new Callable<Long>() {
                    @Override
                    public Long call() {
                        return reservaRepository.insert(reserva7);
                    }
                });
                long reservaId7 = futureReserva7.get();
                // Verificamos si la parcela se ha insertado correctamente
                if (reservaId7 != -1) {
                    Parcela parcela7 = new Parcela("pruebaReserva7", 10, 10.0, "parcela con agua");
                    Future<Long> futureParcela7 = executorService.submit(new Callable<Long>() {
                        @Override
                        public Long call() {
                            return parcelaRepository.insert(parcela7);
                        }
                    });
                    long parcelaId7 = futureParcela7.get();
                    reservaRepository.insertOrUpdateParcelaReservaRel((int) reservaId7, (int) parcelaId7, 1);
                    results.add("Test 7 (Crear Reserva NumCliente No Válido): ERROR");
                } else {
                    results.add("Test 7 (Crear Reserva NumCliente No Válido): OK");
                }

                /*
                 * Test 8: Parcelas Asociadas = 0
                 */
                try {
                    // Fechas válidas en el formato esperado
                    Date fechaEntrada8 = dateFormat.parse("2026-02-24");
                    Date fechaSalida8 = dateFormat.parse("2026-02-25");

                    assert fechaEntrada8 != null;
                    assert fechaSalida8 != null;

                    // Insertar la reserva
                    Reserva reserva8 = new Reserva(fechaEntrada8, fechaSalida8, "Marcos", "603303030", 0.0);
                    Future<Long> futureReserva8 = executorService.submit(() -> reservaRepository.insert(reserva8));
                    long reservaId8 = futureReserva8.get();

                    if (reservaId8 != -1) {
                        // Asociar una parcela con ocupantes = 0
                        Parcela parcela8 = new Parcela("pruebaReserva8", 10, 10.0, "parcela con agua");
                        Future<Long> futureParcela8 = executorService.submit(() -> parcelaRepository.insert(parcela8));
                        long parcelaId8 = futureParcela8.get();

                        // Asociar la parcela a la reserva
                        reservaRepository.insertOrUpdateParcelaReservaRelAsync((int) reservaId8, (int) parcelaId8, 0).get();

                        // Validar si la reserva tiene parcelas válidas
                        int parcelasValidas = reservaRepository.getParcelasCountByReservaId((int) reservaId8);
                        Log.d("Test8", "Parcelas válidas asociadas a la reserva: " + parcelasValidas);

                        if (parcelasValidas > 0) {
                            results.add("Test 8 (Crear Reserva Parcelas Asociadas = 0): ERROR - Se creó una reserva con parcelas inválidas");
                        } else {
                            // Eliminar la reserva y la parcela si no hay parcelas válidas
                            executorService.submit(() -> {
                                reservaRepository.deleteReservaById((int) reservaId8);
                                parcelaRepository.deleteById((int) parcelaId8); // Eliminar la parcela creada
                            }).get();

                            results.add("Test 8 (Crear Reserva Parcelas Asociadas = 0): OK - No se creó la reserva y se eliminó la parcela");
                        }
                    } else {
                        results.add("Test 8 (Crear Reserva Parcelas Asociadas = 0): OK - No se creó la reserva");
                    }
                } catch (ParseException e) {
                    results.add("Test 8 (Crear Reserva Parcelas Asociadas = 0): OK - Error en el formato de fecha");
                } catch (InterruptedException | ExecutionException e) {
                    results.add("Test 8 (Crear Reserva Parcelas Asociadas = 0): ERROR - Excepción: " + e.getMessage());
                }

                /*
                 * Test 9: NumOcupantes > nMaxOcupantes
                 */
                try {
                    Date fechaEntrada9 = dateFormat.parse("2026-02-25");
                    Date fechaSalida9 = dateFormat.parse("2026-02-26");

                    assert fechaSalida9 != null;
                    assert fechaEntrada9 != null;

                    // Crear la reserva
                    Reserva reserva9 = new Reserva(fechaEntrada9, fechaSalida9, "Marcos", "603303030", 0.0);
                    Future<Long> futureReserva9 = executorService.submit(() -> reservaRepository.insert(reserva9));
                    long reservaId9 = futureReserva9.get();

                    if (reservaId9 != -1) {
                        // Crear la parcela
                        Parcela parcela9 = new Parcela("pruebaReserva9", 10, 10.0, "parcela con agua");
                        Future<Long> futureParcela9 = executorService.submit(() -> parcelaRepository.insert(parcela9));
                        long parcelaId9 = futureParcela9.get();

                        // Intentar asociar la parcela con ocupantes > nMaxOcup
                        Future<Void> result = reservaRepository.insertOrUpdateParcelaReservaRelAsync((int) reservaId9, (int) parcelaId9, 11);
                        result.get(); // Esperar a que la operación termine

                        // Verificar si la relación no se creó
                        int parcelasAsociadas = reservaRepository.getParcelasCountByReservaId((int) reservaId9);
                        if (parcelasAsociadas > 0) {
                            results.add("Test 9 (Crear Reserva NumOcupantes > nMaxOcupantes): ERROR - Relación creada con ocupantes inválidos");
                        } else {
                            // Eliminar la reserva y la parcela si la relación no fue válida
                            executorService.submit(() -> {
                                reservaRepository.deleteReservaById((int) reservaId9);
                                parcelaRepository.deleteById((int) parcelaId9); // Eliminar la parcela creada
                            }).get();

                            results.add("Test 9 (Crear Reserva NumOcupantes > nMaxOcupantes): OK - Relación no creada");
                        }
                    } else {
                        results.add("Test 9 (Crear Reserva NumOcupantes > nMaxOcupantes): OK - Reserva no creada");
                    }
                } catch (ParseException e) {
                    results.add("Test 9 (Crear Reserva NumOcupantes > nMaxOcupantes): ERROR - Formato de fecha incorrecto");
                } catch (Exception e) {
                    results.add("Test 9 (Crear Reserva NumOcupantes > nMaxOcupantes): ERROR - Excepción: " + e.getMessage());
                }

                /*
                 * Test 10: NumOcupantes < 0 (poniendo 'a' no deja compilar al ponerlo en numOcupantes)
                 */
                try {
                    Date fechaEntrada10 = dateFormat.parse("2026-02-26");
                    Date fechaSalida10 = dateFormat.parse("2026-02-27");

                    assert fechaSalida10 != null;
                    assert fechaEntrada10 != null;

                    // Crear la reserva
                    Reserva reserva10 = new Reserva(fechaEntrada10, fechaSalida10, "Marcos", "603303030", 0.0);
                    Future<Long> futureReserva10 = executorService.submit(() -> reservaRepository.insert(reserva10));
                    long reservaId10 = futureReserva10.get();

                    if (reservaId10 != -1) {
                        // Crear una parcela
                        Parcela parcela10 = new Parcela("pruebaReserva10", 10, 10.0, "parcela con agua");
                        Future<Long> futureParcela10 = executorService.submit(() -> parcelaRepository.insert(parcela10));
                        long parcelaId10 = futureParcela10.get();

                        // Intentar asociar la parcela con numOcupantes < 0
                        Future<Void> relFuture = reservaRepository.insertOrUpdateParcelaReservaRelAsync((int) reservaId10, (int) parcelaId10, -1);
                        relFuture.get(); // Esperar a que termine la inserción

                        // Validar si la relación no se creó
                        int parcelasAsociadas = reservaRepository.getParcelasCountByReservaId((int) reservaId10);
                        if (parcelasAsociadas > 0) {
                            // Si hay parcelas asociadas, es un error
                            results.add("Test 10 (Crear Reserva NumOcupantes < 0): ERROR - Se creó una relación inválida");
                        } else {
                            // Si no hay parcelas asociadas, todo está correcto
                            results.add("Test 10 (Crear Reserva NumOcupantes < 0): OK - No se creó la relación inválida");
                        }

                        // Eliminar la reserva y la parcela creadas
                        executorService.submit(() -> {
                            reservaRepository.deleteReservaById((int) reservaId10);
                            parcelaRepository.deleteById((int) parcelaId10);
                        }).get();
                    } else {
                        results.add("Test 10 (Crear Reserva NumOcupantes < 0): OK - No se creó la reserva");
                    }
                } catch (ParseException e) {
                    results.add("Test 10 (Crear Reserva NumOcupantes < 0): OK - Error en el formato de fecha");
                } catch (InterruptedException | ExecutionException e) {
                    results.add("Test 10 (Crear Reserva NumOcupantes < 0): ERROR - Excepción: " + e.getMessage());
                }


                /*
                * Test 11: Eliminacion de una reserva
                */
                Integer deletedReserva1 = -1;
                if(reservaId1 != -1){
                    Future<Integer> futureReservaDelete1 = executorService.submit(new Callable<Integer>() {
                        @Override
                        public Integer call() {
                            return reservaRepository.delete(reserva1);
                        }
                    });
                    deletedReserva1 = futureReservaDelete1.get();
                }
                if (deletedReserva1 != -1) {
                    results.add("Test 11 (Eliminar Reserva Existente): OK");
                } else {
                    results.add("Test 11 (Eliminar Reserva Existente): ERROR");
                }

                // Test 12: Modificar reserva con fechas válidas
                Date fechaEntrada13 = dateFormat.parse("2026-02-27");
                Date fechaSalida13 = dateFormat.parse("2026-02-28");
                assert fechaSalida13 != null;
                assert fechaEntrada13 != null;
                Reserva reserva13 = new Reserva(fechaEntrada13, fechaSalida13, "Marcos", "603303030", 0.0);
                Future<Long> futureReserva13 = executorService.submit(() -> reservaRepository.insert(reserva13));
                long reservaId13 = futureReserva13.get();
                reserva13.setId((int) reservaId13);

                if (reservaId13 != -1) {
                    Parcela parcela13 = new Parcela("pruebaReserva13", 10, 10.0, "parcela con agua");
                    Future<Long> futureParcela1 = executorService.submit(() -> parcelaRepository.insert(parcela13));
                    long parcelaId13 = futureParcela1.get();
                    parcela13.setId((int) parcelaId13); // Actualiza el ID en el objeto después de la inserción

                    // Envolver la llamada a insertOrUpdateParcelaReservaRel en un Future
                    reservaRepository.insertOrUpdateParcelaReservaRelAsync((int) reservaId13, (int) parcelaId13, 1).get();
                    // Modificar las fechas
                    reserva13.setFechaEntrada(dateFormat.parse("2025-03-01"));
                    reserva13.setFechaSalida(dateFormat.parse("2025-03-02"));

                    Future<Integer> futureUpdate13 = executorService.submit(() -> reservaRepository.update(reserva13));
                    int updatedRows13 = futureUpdate13.get();

                    if (updatedRows13 > 0) {
                        results.add("Test 12 (Modificar Reserva con fechas válidas): OK");
                    } else {
                        results.add("Test 12 (Modificar Reserva con fechas válidas): ERROR");
                    }
                }

                // Test 13: Modificar reserva con fecha inválida (fechaEntrada > fechaSalida)
                reserva13.setFechaEntrada(dateFormat.parse("2025-03-03"));
                reserva13.setFechaSalida(dateFormat.parse("2025-03-01"));

                Future<Integer> futureUpdate14 = executorService.submit(() -> reservaRepository.update(reserva13));
                int updatedRows14 = futureUpdate14.get();

                if (updatedRows14 == -1) {
                    results.add("Test 13 (Modificar Reserva con fecha inválida): OK - fechaEntrada > fechaSalida");
                } else {
                    results.add("Test 13 (Modificar Reserva con fecha inválida): ERROR");
                }

                // Test 14: Modificar reserva con fecha inválida (fechaEntrada < fechaActual)
                reserva13.setFechaEntrada(dateFormat.parse("2023-03-03"));
                reserva13.setFechaSalida(dateFormat.parse("2025-03-01"));

                Future<Integer> futureUpdate15 = executorService.submit(() -> reservaRepository.update(reserva13));
                int updatedRows15 = futureUpdate15.get();

                if (updatedRows15 == -1) {
                    results.add("Test 14 (Modificar Reserva con fecha inválida): OK - fechaEntrada < fechaActual");
                } else {
                    results.add("Test 14 (Modificar Reserva con fecha inválida): ERROR");
                }

                // Test 15: Modificar reserva con número de cliente inválido
                reserva13.setNumCliente("123abc");

                Future<Integer> futureUpdate16 = executorService.submit(() -> reservaRepository.update(reserva13));
                int updatedRows16 = futureUpdate16.get();

                if (updatedRows16 == -1) {
                    results.add("Test 15 (Modificar Reserva con número de cliente inválido): OK");
                } else {
                    results.add("Test 15 (Modificar Reserva con número de cliente inválido): ERROR");
                }

                // Test 16: Modificar reserva con atributos nulos
                reserva13.setFechaEntrada(null);
                reserva13.setFechaSalida(null);
                reserva13.setNumCliente(null);
                reserva13.setNomCliente(null);

                Future<Integer> futureUpdate17 = executorService.submit(() -> reservaRepository.update(reserva13));
                int updatedRows17 = futureUpdate17.get();

                if (updatedRows17 == -1) {
                    results.add("Test 16 (Modificar Reserva con atributos nulos): OK");
                } else {
                    results.add("Test 16 (Modificar Reserva con atributos nulos): ERROR");
                }
            }
        } catch (Exception e) {
            results.add("Error al ejecutar pruebas: " + e.getMessage());
        }

        return results;
    }
}

