package es.unizar.eina.M15_camping.database;

import androidx.room.TypeConverter;
import java.util.Date;

/**
 * Clase que contiene metodos para convertir entre {@link Date} y {@link Long},
 * permitiendo almacenar fechas como timestamps en la BD.
 */
public class Converters {

    /**
     * Convierte un timestamp (Long) en un objeto {@link Date}.
     *
     * @param value El valor de tipo {@link Long} que representa un timestamp.
     * @return Un objeto {@link Date} correspondiente al timestamp, o {@code null} si el valor es nulo.
     */
    @TypeConverter
    public static Date fromTimestamp(Long value) {
        return value == null ? null : new Date(value);
    }

    /**
     * Convierte un objeto {@link Date} en un timestamp (Long).
     *
     * @param date El objeto {@link Date} a convertir.
     * @return El valor de tipo {@link Long} que representa el timestamp de la fecha,
     * o {@code null} si la fecha es nula.
     */
    @TypeConverter
    public static Long dateToTimestamp(Date date) {
        return date == null ? null : date.getTime();
    }
}
