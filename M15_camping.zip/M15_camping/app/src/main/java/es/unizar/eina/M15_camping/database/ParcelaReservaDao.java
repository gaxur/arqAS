package es.unizar.eina.M15_camping.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * Interfaz que define las operaciones relacionadas con la tabla intermedia ParcelaReservaRel.
 * Esta tabla gestiona las relaciones entre reservas y parcelas.
 */
@Dao
public interface ParcelaReservaDao {

    /**
     * Inserta una nueva relación entre una reserva y una parcela en la tabla {@code ParcelaReservaRel}.
     *
     * @param crossRef Un objeto {@link ParcelaReservaRel} que representa la relación entre una reserva y una parcela.
     * @return El ID de la relación insertada o -1 si ocurrió un error.
     */
    @Insert
    long insert(ParcelaReservaRel crossRef);  // Inserta una relacion entre una reserva y una parcela

    /**
     * Actualiza el número de ocupantes de una relación entre una reserva y una parcela.
     *
     * @param reservaId El ID de la reserva cuya relación se desea actualizar.
     * @param parcelaId El ID de la parcela cuya relación se desea actualizar.
     * @param numOcupantes El nuevo número de ocupantes para la relación entre la reserva y la parcela.
     */
    @Query("UPDATE ParcelaReservaRel SET numOcupantes = :numOcupantes WHERE reservaId = :reservaId AND parcelaId = :parcelaId")
    void updateParcelaReserva(int reservaId, int parcelaId, int numOcupantes);

    /**
     * Obtiene todas las parcelas asociadas a una reserva específica.
     *
     * @param reservaId El identificador de la reserva para la que se quieren obtener las parcelas asociadas.
     * @return Una lista de objetos {@link Parcela} asociados a la reserva.
     */
    @Query("SELECT * FROM parcela INNER JOIN ParcelaReservaRel ON parcela.id = ParcelaReservaRel.parcelaId WHERE ParcelaReservaRel.reservaId = :reservaId")
    List<Parcela> getParcelasByReservaId(int reservaId);

    /**
     * Elimina una relación específica entre una reserva y una parcela de la tabla {@code ParcelaReservaRel}.
     *
     * @param reservaId El identificador de la reserva de la que se quiere eliminar la relación.
     * @param parcelaId El identificador de la parcela de la que se quiere eliminar la relación.
     */
    @Query("DELETE FROM ParcelaReservaRel WHERE reservaId = :reservaId AND parcelaId = :parcelaId")
    void deleteParcelaReserva(int reservaId, int parcelaId);

    @Query("DELETE FROM ParcelaReservaRel WHERE reservaId = :reservaId")
    void deleteParcelasByReservaId(int reservaId);


    /**
     * Obtiene el número de ocupantes de una relación específica entre una reserva y una parcela.
     *
     * @param reservaId El identificador de la reserva.
     * @param parcelaId El identificador de la parcela.
     * @return El número de ocupantes asociados a la relación.
     */
    @Query("SELECT numOcupantes FROM ParcelaReservaRel WHERE reservaId = :reservaId AND parcelaId = :parcelaId LIMIT 1")
    int getNumeroOcupantes(int reservaId, int parcelaId);

    /**
     * Obtiene la cantidad de parcelas asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva.
     * @return El número de parcelas asociadas a la reserva.
     */
    @Query("SELECT COUNT(*) FROM ParcelaReservaRel WHERE reservaId = :reservaId AND numOcupantes > 0")
    int getParcelasCountByReservaId(int reservaId);

    /**
     * Cuenta el número de parcelas con {@code numOcupantes >= 1} asociadas a una reserva.
     *
     * @param reservaId El ID de la reserva.
     * @return El número de parcelas con ocupantes mayores o iguales a 1.
     */
    @Query("SELECT COUNT(*) FROM ParcelaReservaRel WHERE reservaId = :reservaId AND numOcupantes >= 1")
    int getParcelasConOcupantesCount(int reservaId);

    /**
     * Obtiene las parcelas disponibles en el rango de fechas especificado, excluyendo aquellas que están ocupadas
     * por una reserva en el mismo rango de fechas.
     *
     * @param fechaEntrada La fecha de entrada de la reserva.
     * @param fechaSalida La fecha de salida de la reserva.
     * @return Una lista de parcelas disponibles para la reserva.
     */
    @Query("SELECT * FROM parcela " +
            "WHERE id NOT IN ( " +
            "    SELECT parcelaId FROM ParcelaReservaRel " +
            "    INNER JOIN reserva ON ParcelaReservaRel.reservaId = reserva.id " +
            "    WHERE (reserva.fechaEntrada < :fechaSalida AND reserva.fechaSalida > :fechaEntrada) " +
            ")")
    List<Parcela> getParcelasDisponibles(long fechaEntrada, long fechaSalida);

    /**
     * Elimina todas las relaciones entre parcelas y reservas de la tabla {@code ParcelaReservaRel}.
     * Este método puede usarse para limpiar las relaciones de la base de datos.
     */
    @Query("DELETE FROM parcelareservarel")
    void deleteAll();

    /**
     * DAO para obtener una parcela específica por su ID.
     *
     * @param parcelaId El ID de la parcela que se desea obtener.
     * @return Un objeto {@link Parcela} correspondiente al ID proporcionado o {@code null} si no se encuentra.
     */
    @Query("SELECT * FROM Parcela WHERE id = :parcelaId LIMIT 1")
    Parcela getParcelaById(int parcelaId);

}


