package es.unizar.eina.M15_camping.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

/** Clase anotada como entidad que representa la relacion many to many entre parcelas y reservas
 *  y que consta del id de la parcela, id de la reserva, y numero de ocupantes */
@Entity(tableName = "ParcelaReservaRel",
        primaryKeys = {"reservaId", "parcelaId"},
        foreignKeys = {
                @ForeignKey(entity = Reserva.class,
                        parentColumns = "id", // Debe coincidir con la clave primaria en Reserva
                        childColumns = "reservaId",
                        onDelete = ForeignKey.CASCADE),
                @ForeignKey(entity = Parcela.class,
                        parentColumns = "id", // Debe coincidir con la clave primaria en Parcela
                        childColumns = "parcelaId",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {@Index("reservaId"), @Index("parcelaId")}
)
public class ParcelaReservaRel {
    @ColumnInfo(name = "reservaId")
    public int reservaId;

    @ColumnInfo(name = "parcelaId")
    public int parcelaId;

    @ColumnInfo(name = "numOcupantes")
    public int numOcupantes;

    public ParcelaReservaRel(int reservaId, int parcelaId, int numOcupantes) {
        this.reservaId = reservaId;
        this.parcelaId = parcelaId;
        this.numOcupantes = numOcupantes;
    }

    /**
     * Devuelve una representación en formato de cadena (String) del objeto {@link ParcelaReservaRel}.
     * Esta representación incluye los valores de los atributos {@code reservaId}, {@code parcelaId}
     * y {@code numOcupantes}, lo que facilita la visualización del objeto en los registros de log o
     * en la depuración.
     *
     * @return Una cadena con la representación del objeto, que incluye los valores de los campos
     *         {@code reservaId}, {@code parcelaId} y {@code numOcupantes}.
     */
    @Override
    public String toString() {
        return "ParcelaReservaRel{" +
                "reservaId=" + reservaId +
                ", parcelaId=" + parcelaId +
                ", numOcupantes=" + numOcupantes +
                '}';
    }

}

