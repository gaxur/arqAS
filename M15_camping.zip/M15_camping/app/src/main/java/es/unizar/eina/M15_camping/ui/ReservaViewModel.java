package es.unizar.eina.M15_camping.ui;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;
import es.unizar.eina.M15_camping.database.Reserva;
import es.unizar.eina.M15_camping.database.ReservaRepository;

/**
 * Clase ViewModel para gestionar las reservas.
 * Proporciona acceso a los datos de la BD a traves del repositorio {@link ReservaRepository}.
 * Gestiona operaciones de insercion, actualizacion y eliminacion, así como la ordenacion de reservas.
 */
public class ReservaViewModel extends AndroidViewModel {
    private final ReservaRepository mRepository;
    private final LiveData<List<Reserva>> mAllReservas;

    /**
     * Constructor de {@link ReservaViewModel}.
     *
     * @param application La aplicacion contiene el contexto de la actividad.
     */
    public ReservaViewModel(Application application) {
        super(application);
        mRepository = new ReservaRepository(application);
        mAllReservas = mRepository.getReservasOrderedByFechaEntrada();
    }

    /**
     * Devuelve todas las reservas ordenadas por fecha de entrada de menor a mayor
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    public LiveData<List<Reserva>> getReservasOrderedByFechaEntrada() { return mAllReservas; }

    /**
     * Devuelve todas las reservas ordenadas por el nombre del cliente de menor a mayor
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    public LiveData<List<Reserva>> getReservasOrderedByNomCliente() {
        return mRepository.getReservasOrderedByNomCliente();
    }

    /**
     * Devuelve todas las reservas ordenadas por el número del cliente
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    public LiveData<List<Reserva>> getReservasOrderedByNumCliente() {
        return mRepository.getReservasOrderedByNumCliente();
    }

    /**
     * Inserta una nueva reserva en la base de datos.
     *
     * @param reserva El objeto {@link Reserva} que se desea insertar.
     */
    public void insert(Reserva reserva) {
        mRepository.insert(reserva);
    }

    /**
     * Actualiza una reserva existente en la base de datos.
     *
     * @param reserva El objeto {@link Reserva} que se desea actualizar.
     */
    public void update(Reserva reserva) {
        mRepository.update(reserva);
    }

    /**
     * Elimina una reserva existente de la base de datos.
     *
     * @param reserva El objeto {@link Reserva} que se desea eliminar.
     */
    public void delete(Reserva reserva) {
        mRepository.delete(reserva);
    }
}
