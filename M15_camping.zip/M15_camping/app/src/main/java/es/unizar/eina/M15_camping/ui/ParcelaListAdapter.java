package es.unizar.eina.M15_camping.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import es.unizar.eina.M15_camping.database.Parcela;


/**
 * Adaptador para gestionar y mostrar una lista de parcelas en un RecyclerView.
 * Utiliza {@link ListAdapter} para manejar actualizaciones.
 */
public class ParcelaListAdapter extends ListAdapter<Parcela, ParcelaViewHolder> {
    private int position;
    private OnItemClickListener onClickListener;

    /**
     * Interfaz para manejar clics en los elementos del RecyclerView.
     */
    public interface OnItemClickListener {
        void onItemClick(Parcela parcela);
    }

    /**
     * Establece el listener para los clics normales.
     *
     * @param listener La implementación del listener.
     */
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onClickListener = listener;
    }

    /**
     * Obtiene la posicion actual del elemento seleccionado en la lista.
     *
     * @return La posicion actual del elemento seleccionado.
     */
    public int getPosition() {
        return position;
    }

    /**
     * Establece la posicion del elemento seleccionado en la lista.
     *
     * @param position La posicion que se desea establecer como seleccionada.
     */
    public void setPosition(int position) {
        this.position = position;
    }

    /**
     * Constructor del adaptador.
     *
     * @param diffCallback El objeto {@link DiffUtil.ItemCallback} utilizado para calcular diferencias entre elementos.
     */
    public ParcelaListAdapter(@NonNull DiffUtil.ItemCallback<Parcela> diffCallback) {
        super(diffCallback);
    }

    /**
     * Crea un nuevo {@link ParcelaViewHolder} para representar un elemento de la lista.
     *
     * @param parent   El grupo de vistas al que se añadira la nueva vista.
     * @param viewType El tipo de vista del nuevo elemento.
     * @return Un nuevo {@link ParcelaViewHolder}.
     */
    @Override
    public ParcelaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return ParcelaViewHolder.create(parent);
    }

    /**
     * Obtiene el elemento actualmente seleccionado en la lista.
     *
     * @return El objeto {@link Parcela} en la posicion seleccionada.
     */
    public Parcela getCurrent() {
        return getItem(getPosition());
    }

    /**
     * Se vincula los datos del objeto {@link Parcela} a la vista representada por {@link ParcelaViewHolder}.
     * Se configura un listener para manejar esperas/selcciones en los elementos.
     *
     * @param holder   El {@link ParcelaViewHolder} que contiene la vista del elemento.
     * @param position La posición del elemento en la lista.
     */
    @Override
    public void onBindViewHolder(ParcelaViewHolder holder, int position) {

        Parcela current = getItem(position);
        holder.bind(current); // Pasar el objeto Parcela completo

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                setPosition(holder.getAdapterPosition());
                return false;
            }
        });

        // Configurar el OnClickListener (para clics normales en esta pantalla)
        holder.itemView.setOnClickListener(v -> {
            if (onClickListener != null) {
                onClickListener.onItemClick(current); // Llamar al listener configurado
            }
        });
    }

    /**
     * Clase interna para calcular diferencias entre elementos de la lista de parcelas.
     * Utilizada por {@link ListAdapter} para optimizar las actualizaciones del RecyclerView.
     */
    static class ParcelaDiff extends DiffUtil.ItemCallback<Parcela> {

        /**
         * Comprueba si dos objetos {@link Parcela} representan el mismo elemento en la lista.
         *
         * @param oldItem El elemento antiguo.
         * @param newItem El nuevo elemento.
         * @return {@code true} si ambos objetos tienen el mismo ID; {@code false} en caso contrario.
         */
        @Override
        public boolean areItemsTheSame(@NonNull Parcela oldItem, @NonNull Parcela newItem) {
            //android.util.Log.d ( "NoteDiff" , "areItemsTheSame " + oldItem.getId() + " vs " + newItem.getId() + " " +  (oldItem.getId() == newItem.getId()));
            return oldItem.getId() == newItem.getId();
        }

        /**
         * Comprueba si los contenidos visuales de dos objetos {@link Parcela} son iguales.
         *
         * @param oldItem El elemento antiguo.
         * @param newItem El nuevo elemento.
         * @return {@code true} si los titulos de ambas parcelas son iguales; {@code false} en caso contrario.
         */
        @Override
        public boolean areContentsTheSame(@NonNull Parcela oldItem, @NonNull Parcela newItem) {
            //android.util.Log.d ( "NoteDiff" , "areContentsTheSame " + oldItem.getTitle() + " vs " + newItem.getTitle() + " " + oldItem.getTitle().equals(newItem.getTitle()));
            // We are just worried about differences in visual representation, i.e. changes in the title
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }
}
