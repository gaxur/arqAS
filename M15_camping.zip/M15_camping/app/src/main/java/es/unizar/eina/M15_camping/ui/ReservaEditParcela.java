package es.unizar.eina.M15_camping.ui;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.concurrent.Executors;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.database.Parcela;
import es.unizar.eina.M15_camping.database.ReservaRepository;

public class ReservaEditParcela extends AppCompatActivity {

    private ParcelaViewModel mParcelaViewModel;
    private ReservaRepository mReservaRepository;

    private RecyclerView mRecyclerView;
    private ReservaParcelaListAdapter mAdapter;

    private int reservaId;

    /**
     * Método de ciclo de vida de la actividad que se ejecuta cuando la actividad es creada.
     * Inicializa los elementos de la interfaz de usuario y configura los eventos de clic.
     * También valida la información de la reserva pasada en el intent, como el ID de la reserva y las fechas de entrada y salida.
     *
     * @param savedInstanceState El estado guardado de la actividad, si está disponible.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva_edit_parcelas);

        // Obtener el ID de la reserva y las fechas desde el intent
        reservaId = getIntent().getIntExtra("RESERVA_ID", -1);
        long fechaEntrada = getIntent().getLongExtra("FECHA_ENTRADA", -1);
        long fechaSalida = getIntent().getLongExtra("FECHA_SALIDA", -1);

        // Validación inicial
        if (reservaId == -1 || fechaEntrada == -1 || fechaSalida == -1) {
            Toast.makeText(this, "Error: Información de la reserva incompleta.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Inicializar ViewModel y Repositorio
        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mReservaRepository = new ReservaRepository(getApplication());

        // Configurar RecyclerView
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new ReservaParcelaListAdapter(new ReservaParcelaListAdapter.ParcelaDiff(), mReservaRepository, reservaId);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Obtener las parcelas disponibles y las asociadas
        Executors.newSingleThreadExecutor().execute(() -> {
            // Parcelas disponibles entre las fechas especificadas
            List<Parcela> parcelasDisponibles = mReservaRepository.getParcelasDisponibles(fechaEntrada, fechaSalida);

            // Parcelas asociadas a la reserva actual
            List<Parcela> parcelasAsociadas = mReservaRepository.getParcelasPorReserva(reservaId);

            // Combinar las listas sin duplicados
            for (Parcela asociada : parcelasAsociadas) {
                if (!parcelasDisponibles.contains(asociada)) {
                    parcelasDisponibles.add(asociada);
                }
            }

            // Actualizar el adaptador en el hilo principal
            runOnUiThread(() -> mAdapter.submitList(parcelasDisponibles));
        });

        // Configurar el listener de clic en el adaptador
        mAdapter.setOnItemClickListener(parcela -> {
            mostrarPopUpModificarOcupantes(parcela); // Llama al diálogo para modificar ocupantes
        });
    }

    /**
     * Muestra un diálogo para modificar el número de ocupantes de una parcela.
     *
     * @param parcela La parcela seleccionada.
     */
    private void mostrarPopUpModificarOcupantes(Parcela parcela) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Modificar número de ocupantes ('" + parcela.getTitle() + "')");
        builder.setMessage("Introduce el número de ocupantes para esta parcela (Máx: " + parcela.getNMaxOcup() + "):");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);

        Executors.newSingleThreadExecutor().execute(() -> {
            int ocupantesActuales = mReservaRepository.getNumeroOcupantes(reservaId, parcela.getId());
            runOnUiThread(() -> input.setText(String.valueOf(ocupantesActuales)));
        });

        builder.setView(input);

        builder.setPositiveButton("Guardar", (dialog, which) -> {
            String inputText = input.getText().toString();
            if (!TextUtils.isEmpty(inputText)) {
                try {
                    int numOcupantes = Integer.parseInt(inputText);

                    // Validar que el número de ocupantes no exceda el máximo permitido
                    if (numOcupantes > parcela.getNMaxOcup()) {
                        Toast.makeText(this, "El número de ocupantes no puede superar el máximo permitido (" + parcela.getNMaxOcup() + ").", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Executors.newSingleThreadExecutor().execute(() -> {
                        int parcelasConOcupantes = mReservaRepository.getParcelasConOcupantesCount(reservaId);

                        if (numOcupantes == 0 && parcelasConOcupantes <= 1) {
                            runOnUiThread(() -> Toast.makeText(
                                    this,
                                    "Debe haber al menos una parcela con ocupantes mayores a 0.",
                                    Toast.LENGTH_SHORT).show());
                            return;
                        }
                        try {
                            // Insertar o actualizar la relación, incluyendo parcelas con 0 ocupantes
                            mReservaRepository.insertOrUpdateParcelaReservaRel(reservaId, parcela.getId(), numOcupantes);

                            // Calcular el precio total sumando los precios de todas las parcelas asociadas
                            double precioTotal = calcularPrecioTotal(reservaId);

                            // Actualizar el precio total en la base de datos
                            mReservaRepository.actualizarPrecioTotal(reservaId, precioTotal);

                            double precioTotalFinal = mReservaRepository.getReservaById(reservaId).getPrecioTotal();
                            Log.d("ReservaEditParcela","Precio total final: " + precioTotalFinal);

                            runOnUiThread(() -> {
                                Toast.makeText(this, "Precio Actualizado", Toast.LENGTH_SHORT).show();
                                mAdapter.notifyDataSetChanged(); // Refresca la vista
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> Toast.makeText(this, "Error al guardar en la base de datos.", Toast.LENGTH_SHORT).show());
                        }
                    });
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Número de ocupantes inválido.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "El campo no puede estar vacío.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    /**
     * Calcula el precio total de la reserva sumando el precio de todas las parcelas asociadas,
     * excluyendo las parcelas con 0 ocupantes.
     *
     * @param reservaId ID de la reserva.
     * @return El precio total de la reserva.
     */
    private double calcularPrecioTotal(int reservaId) {
        // Obtener la lista de todas las parcelas asociadas a la reserva
        List<Parcela> parcelas = mReservaRepository.getParcelasPorReserva(reservaId);

        // Obtener las fechas de entrada y salida de la reserva
        long fechaEntrada = mReservaRepository.getFechaEntrada(reservaId);
        long fechaSalida = mReservaRepository.getFechaSalida(reservaId);

        if (fechaSalida <= fechaEntrada) {
            runOnUiThread(() -> Toast.makeText(this, "La fecha de salida debe ser posterior a la fecha de entrada.", Toast.LENGTH_SHORT).show());
            return 0.0;
        }

        // Calcular la diferencia de fechas en días
        long diferenciaMillis = fechaSalida - fechaEntrada;
        int dias = (int) (diferenciaMillis / (1000 * 60 * 60 * 24));

        // Sumar los precios de todas las parcelas (excluyendo las de 0 ocupantes)
        double precioTotal = 0.0;
        for (Parcela parcela : parcelas) {
            int ocupantes = mReservaRepository.getNumeroOcupantes(reservaId, parcela.getId());
            if (ocupantes > 0) { // Solo incluir parcelas con ocupantes
                precioTotal += parcela.getPrecioPersona() * ocupantes * dias;
            }
        }

        // Redondear el total a 2 decimales usando BigDecimal
        BigDecimal bd = new BigDecimal(precioTotal).setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    /**
     * Método que se ejecuta cuando el usuario presiona el botón de retroceso en la actividad.
     * Si la reserva temporal ha sido guardada, se eliminan las parcelas asociadas y la reserva temporal
     * de la base de datos antes de que la actividad sea destruida.
     *
     * Este método asegura que no se dejen registros de reserva temporal si la actividad es abandonada
     * antes de guardar permanentemente los datos.
     */
    @Override
    public void onBackPressed() {
        Executors.newSingleThreadExecutor().execute(() -> {
            // Calcular el precio total al presionar "Atrás"
            double precioTotal = calcularPrecioTotal(reservaId);

            runOnUiThread(() -> {
                Toast.makeText(this, "El precio total de la reserva es: " + precioTotal + "€.", Toast.LENGTH_LONG).show();

                // Llamar a la funcionalidad predeterminada de "Atrás"
                ReservaEditParcela.super.onBackPressed();
            });
        });
    }


}


