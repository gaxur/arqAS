package es.unizar.eina.M15_camping.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

/** Clase anotada como entidad que representa una reserva y que consta de nombre del cliente, fecha de entrada,
 *  fecha de salida y precio total */
@Entity(tableName = "reserva")
public class Reserva {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @NonNull
    @ColumnInfo(name = "fechaEntrada")
    private Date fechaEntrada;

    @NonNull
    @ColumnInfo(name = "fechaSalida")
    private Date fechaSalida;

    @NonNull
    @ColumnInfo(name = "nomCliente")
    private String nomCliente;

    @NonNull
    @ColumnInfo(name = "numCliente")
    private String numCliente;

    @NonNull
    @ColumnInfo(name = "precioTotal")
    private Double precioTotal;

    public Reserva(@NonNull Date fechaEntrada, @NonNull Date fechaSalida, @NonNull String nomCliente,
                   @NonNull String numCliente, @NonNull Double precioTotal) {
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.nomCliente = nomCliente;
        this.numCliente = numCliente;
        this.precioTotal = precioTotal;
    }


    /** Devuelve el identificador de la reserva */
    public int getId() { return this.id; }

    /** Permite actualizar el identificador de una reserva */
    public void setId(int id) { this.id = id; }

    /** Devuelve la fecha de entrada de la reserva */
    public Date getFechaEntrada() { return this.fechaEntrada; }

    /** Permite actualizar la fecha de entrada de una reserva */
    public void setFechaEntrada(Date fechaEntrada) { this.fechaEntrada = fechaEntrada; }

    /** Devuelve la fecha de salida de la reserva */
    public Date getFechaSalida() { return this.fechaSalida; }

    /** Permite actualizar la fecha de salida de una reserva */
    public void setFechaSalida(Date fechaSalida) { this.fechaSalida = fechaSalida; }

    /** Devuelve el nombre del cliente de la reserva */
    public String getNomCliente() { return this.nomCliente; }

    /** Permite actualizar el nombre del cliente de una reserva */
    public void setNomCliente(String nomCliente) { this.nomCliente = nomCliente; }

    /** Devuelve el número de cliente de la reserva */
    public String getNumCliente() { return this.numCliente; }

    /** Permite actualizar el número de cliente de una reserva */
    public void setNumCliente(String numCliente) { this.numCliente = numCliente; }

    /** Devuelve el precio total de la reserva */
    public Double getPrecioTotal() { return this.precioTotal; }

    /** Permite actualizar el precio total de una reserva */
    public void setPrecioTotal(Double precioTotal) { this.precioTotal = precioTotal; }
}
