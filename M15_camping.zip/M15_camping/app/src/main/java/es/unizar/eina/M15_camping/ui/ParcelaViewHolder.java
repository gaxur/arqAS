package es.unizar.eina.M15_camping.ui;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import es.unizar.eina.M15_camping.R;
import es.unizar.eina.M15_camping.database.Parcela;

/**
 * Clase ViewHolder para representar y gestionar un elemento de la lista de parcelas en un RecyclerView.
 * Implementa {@link View.OnCreateContextMenuListener} para proporcionar un menu en cada elemento.
 */
class ParcelaViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
    private final TextView mParcelaItemView;

    /**
     * Constructor privado para inicializar el ViewHolder.
     *
     * @param itemView La vista del elemento representada por este ViewHolder.
     */
    private ParcelaViewHolder(View itemView) {
        super(itemView);
        mParcelaItemView = itemView.findViewById(R.id.textView);

        itemView.setOnCreateContextMenuListener(this);
    }

    /**
     * Vincula un objeto {@link Parcela} al ViewHolder, mostrando su información en la vista.
     *
     * @param parcela El objeto {@link Parcela} que se debe representar en este ViewHolder.
     */
    public void bind(Parcela parcela) {
        // Mostrar el título y el ID en el formato "Nombre (ID)"
        String text = parcela.getTitle();
        mParcelaItemView.setText(text);
        itemView.findViewById(R.id.parcela_status).setVisibility(View.GONE);
    }

    /**
     * Crea una nueva instancia de {@link ParcelaViewHolder} en el layout correspondiente.
     *
     * @param parent El contenedor donde se añadira la vista modificada.
     * @return Una nueva instancia de {@link ParcelaViewHolder}.
     */
    static ParcelaViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_item, parent, false);
        return new ParcelaViewHolder(view);
    }

    /**
     * Crea un menu para este elemento de la lista.
     * Agrega opciones para editar y eliminar la parcela correspondiente.
     *
     * @param menu     El menu donde se añadiran las opciones (pulsacion larga de parcela).
     * @param v        La vista asociada al menu contextual.
     * @param menuInfo Informacion adicional sobre el contexto del menu.
     */
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        //super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, MenuParcelas.DELETE_ID, Menu.NONE, R.string.delete_parcela);
        menu.add(Menu.NONE, MenuParcelas.EDIT_ID, Menu.NONE, R.string.edit_parcela);
    }
}
