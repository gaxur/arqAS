package es.unizar.eina.M15_camping.ui;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import es.unizar.eina.M15_camping.database.Parcela;
import es.unizar.eina.M15_camping.database.ReservaRepository;
import es.unizar.eina.M15_camping.test.UnitTests;
import es.unizar.eina.send.SendAbstraction;
import es.unizar.eina.send.SendAbstractionImpl;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import es.unizar.eina.M15_camping.R;
import kotlin.Unit;

import static androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * Actividad principal de la aplicacion para gestionar el menu de reservas.
 * Permite listar, crear, editar ,eliminar y enviar informe de reservas, asi como ordenarlas y
 * cambiar a la pantalla de parcelas.
 */
public class MenuReservas extends AppCompatActivity {
    private ReservaViewModel mReservaViewModel;

    static final int SEND_ID = Menu.FIRST;
    static final int SEND_ID_2 = Menu.FIRST + 7;
    static final int DELETE_ID = Menu.FIRST + 1;
    static final int EDIT_ID = Menu.FIRST + 2;
    static final int CHANGE_ID_RESERVA = Menu.FIRST + 3;
    static final int ORD_ID_FECHAENTRADA = Menu.FIRST + 4;
    static final int ORD_ID_NOMCLIENTE = Menu.FIRST + 5;
    static final int ORD_ID_NUMCLIENTE = Menu.FIRST + 6;

    RecyclerView mRecyclerView;

    ReservaListAdapter mAdapter;

    ReservaRepository mReservaRepository;

    FloatingActionButton mFab;
    Button ordButton;

    Button testButton;

    /**
     * Inicializa la actividad y configura la lista de reservas, el ViewModel y los botones tanto
     * para crear una reserva, como para ordenarlas.
     * @param savedInstanceState Estado guardado de la instancia anterior (inicialización y configuración).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva);
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new ReservaListAdapter(new ReservaListAdapter.ReservaDiff());
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);

        mReservaRepository = new ReservaRepository(getApplication());

        mReservaViewModel.getReservasOrderedByFechaEntrada().observe(this, reservas -> {
            // Actualiza la copia en caché de las parcelas en el adaptador.
            mAdapter.submitList(reservas);
        });

        mFab = findViewById(R.id.fab);
        mFab.setOnClickListener(view -> createReserva());
        // añadimos el boton para ordenar
        ordButton = findViewById(R.id.ordButton);
        ordButton.setOnClickListener(view -> onOrderOptionMenu());
        registerForContextMenu(mRecyclerView);
        // añadimos el boton para ejecutar los tests de Reservas
        registerForContextMenu(mRecyclerView);
        testButton = findViewById(R.id.testButton);
        TextView testResults = findViewById(R.id.testResultsTextView);
        testButton.setOnClickListener(view -> {
            UnitTests tests = new UnitTests(getApplication());
            List<String> results = tests.ejecutarTests("reservas");
            testResults.setVisibility(View.VISIBLE);
            StringBuilder resultText = new StringBuilder();
            for (String result : results) {
                resultText.append(result).append("\n");
            }
            testResults.setText(resultText.toString());
        });

    }

    /**
     * Crea un menú de opciones que incluye la opción de cambiar a la pantalla de parcelas.
     * @param menu El menú donde se agregará la opción de cambiar a Parcelas.
     * @return {@code true} si se crea correctamente, {@code false} en caso contrario.
     */
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(Menu.NONE, CHANGE_ID_RESERVA, Menu.NONE, R.string.change_parcela);
        return result;
    }

    /**
     * Muestra un menú emergente (popup) con opciones para ordenar la lista de reservas.
     * @return {@code true} si se utiliza de forma correcta, {@code false} en caso contrario.
     */
    public boolean onOrderOptionMenu() {
        // Crear el PopupMenu anclado al botón ordButton
        PopupMenu popup = new PopupMenu(this, ordButton);

        // Agregar opciones de ordenación programáticamente
        popup.getMenu().add(0, ORD_ID_FECHAENTRADA, 1, R.string.ordenar_reserva_fechaEntrada);
        popup.getMenu().add(0, ORD_ID_NUMCLIENTE, 2, R.string.ordenar_reserva_NumCliente);
        popup.getMenu().add(0, ORD_ID_NOMCLIENTE, 3, R.string.ordenar_reserva_NomCliente);

        // Manejar las opciones seleccionadas
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case ORD_ID_FECHAENTRADA: // Ordenar por ID
                    mReservaViewModel.getReservasOrderedByFechaEntrada().observe(this, reservas -> {
                        mAdapter.submitList(reservas);
                    });
                    return true;
                case ORD_ID_NUMCLIENTE: // Ordenar por Ocupantes Máximos
                    mReservaViewModel.getReservasOrderedByNumCliente().observe(this, reservas -> {
                        mAdapter.submitList(reservas);
                    });
                    return true;
                case ORD_ID_NOMCLIENTE: // Ordenar por Precio
                    mReservaViewModel.getReservasOrderedByNomCliente().observe(this, reservas -> {
                        mAdapter.submitList(reservas);
                    });
                    return true;
                default:
                    return false;
            }
        });
        // Mostrar el PopupMenu
        popup.show();
        return true;
    }

    /**
     * Maneja la selección de opciones introducidas en la clase "Menu", en el menú de Reservas.
     * @param item La opción seleccionada.
     * @return {@code true} si se utliza correctamente, {@code false} en caso contrario.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case CHANGE_ID_RESERVA:
                cambiarParcelas();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Cambia a la actividad {@link MenuParcelas}.
     */
    private void cambiarParcelas() {
        Intent intent = new Intent(this, MenuParcelas.class);
        startActivity(intent);
    }

    /**
     * Maneja las opciones seleccionadas tras pulsar una reserva de la lista de reservas.
     * @param item La opción seleccionada.
     * @return {@code true} si se maneja correctamente, {@code false} en caso contrario.
     */
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        es.unizar.eina.M15_camping.database.Reserva current = mAdapter.getCurrent();
        switch (item.getItemId()) {
            case DELETE_ID:
                Toast.makeText(
                        getApplicationContext(),
                        "Deleting " + current.getNomCliente(),
                        Toast.LENGTH_LONG).show();
                mReservaViewModel.delete(current);
                return true;
            case EDIT_ID:
                editReserva(current);
                return true;
            case SEND_ID:
                Executors.newSingleThreadExecutor().execute(() -> {
                    // Verificar si la reserva tiene parcelas asociadas
                    List<Parcela> parcelas = mReservaRepository.getParcelasByReservaId(current.getId());

                    if (parcelas == null || parcelas.isEmpty()) {
                        // Si no tiene parcelas, mostrar mensaje de error y evitar el envío
                        runOnUiThread(() -> Toast.makeText(MenuReservas.this, "La reserva no tiene parcelas asociadas. No se puede enviar.", Toast.LENGTH_SHORT).show());
                        return; // Salir del método sin hacer nada más
                    }

                    double recalculatedPrice = mReservaRepository.calculateTotalPrice(current.getId());
                    current.setPrecioTotal(recalculatedPrice); // Actualiza el precio en el objeto actual

                    // Preparar el mensaje
                    String message = "Reserva para " + current.getNomCliente() + " desde " +
                            new SimpleDateFormat("yyyy-MM-dd").format(current.getFechaEntrada()) +
                            " hasta " + new SimpleDateFormat("yyyy-MM-dd").format(current.getFechaSalida()) +
                            ". Precio total: " + current.getPrecioTotal() + "€.";

                    // Usar la abstracción para enviar por WhatsApp
                    SendAbstraction sender = new SendAbstractionImpl(this, "WhatsApp"); // Cambia a "WhatsApp"
                    sender.send(current.getNumCliente(), message);

                    runOnUiThread(() -> Toast.makeText(this, "Mensaje enviado correctamente.", Toast.LENGTH_SHORT).show());
                });
                break;
            case SEND_ID_2:
                Executors.newSingleThreadExecutor().execute(() -> {
                    // Verificar si la reserva tiene parcelas asociadas
                    List<Parcela> parcelas = mReservaRepository.getParcelasByReservaId(current.getId());

                    if (parcelas == null || parcelas.isEmpty()) {
                        // Si no tiene parcelas, mostrar mensaje de error y evitar el envío
                        runOnUiThread(() -> Toast.makeText(MenuReservas.this, "La reserva no tiene parcelas asociadas. No se puede enviar.", Toast.LENGTH_SHORT).show());
                        return; // Salir del método sin hacer nada más
                    }

                    double recalculatedPrice = mReservaRepository.calculateTotalPrice(current.getId());
                    current.setPrecioTotal(recalculatedPrice); // Actualiza el precio en el objeto actual

                    // Preparar el mensaje
                    String message = "Reserva para " + current.getNomCliente() + " desde " +
                            new SimpleDateFormat("yyyy-MM-dd").format(current.getFechaEntrada()) +
                            " hasta " + new SimpleDateFormat("yyyy-MM-dd").format(current.getFechaSalida()) +
                            ". Precio total: " + current.getPrecioTotal() + "€.";

                    // Usar la abstracción para enviar por WhatsApp
                    SendAbstraction sender = new SendAbstractionImpl(this, "SMS"); // Cambia a "WhatsApp"
                    sender.send(current.getNumCliente(), message);

                    runOnUiThread(() -> Toast.makeText(this, "Mensaje enviado correctamente.", Toast.LENGTH_SHORT).show());
                });
                break;
        }
        return super.onContextItemSelected(item);
    }

    /**
     * Se lanza la creación de una nueva reserva.
     */
    private void createReserva() {
        mStartCreateReserva.launch(new Intent(this, ReservaEdit.class));
    }

    /**
     * Lanzador de actividades para manejar la creación de una nueva reserva.
     * Llama al método {@link ExecuteActivityResult#process(Bundle, es.unizar.eina.M15_camping.database.Reserva)}
     * para insertar la reserva en el {@link ReservaViewModel}.
     */
    ActivityResultLauncher<Intent> mStartCreateReserva = newActivityResultLauncher(new ExecuteActivityResult() {
        @Override
        public void process(Bundle extras, es.unizar.eina.M15_camping.database.Reserva reserva) {
            mReservaViewModel.insert(reserva);
        }
    });

    /**
     * Método auxiliar para registrar un nuevo {@link ActivityResultLauncher}.
     * Método que encapsula la lógica para manejar los resultados de reservas.
     *
     * @param executable Implementación de la interfaz {@link ExecuteActivityResult}
     *                   para procesar los datos devueltos desde una actividad.
     * @return Un {@link ActivityResultLauncher}
     */
    ActivityResultLauncher<Intent> newActivityResultLauncher(ExecuteActivityResult executable) {
        return registerForActivityResult(
                new StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle extras = result.getData().getExtras();

                        // Convertimos los valores de fecha de long a Date
                        Date fechaEntrada = new Date(extras.getLong(ReservaEdit.RESERVA_FECHA_ENTRADA));
                        Date fechaSalida = new Date(extras.getLong(ReservaEdit.RESERVA_FECHA_SALIDA));

                        es.unizar.eina.M15_camping.database.Reserva reserva = new es.unizar.eina.M15_camping.database.Reserva(
                                fechaEntrada,
                                fechaSalida,
                                extras.getString(ReservaEdit.RESERVA_NOM_CLIENTE),
                                extras.getString(ReservaEdit.RESERVA_NUM_CLIENTE),
                                extras.getDouble(ReservaEdit.RESERVA_PRECIO_TOTAL)
                        );
                        executable.process(extras, reserva);
                    }
                });
    }

    /**
     * Se lanza la edición de una reserva existente.
     * @param current La reserva seleccionada para editar.
     */
    private void editReserva(es.unizar.eina.M15_camping.database.Reserva current) {
        Intent intent = new Intent(this, ReservaEdit.class);

        // Convertimos las fechas al formato "yyyy-MM-dd" antes de enviarlas al Intent
        intent.putExtra(ReservaEdit.RESERVA_FECHA_ENTRADA, current.getFechaEntrada().getTime());
        intent.putExtra(ReservaEdit.RESERVA_FECHA_SALIDA, current.getFechaSalida().getTime());

        intent.putExtra(ReservaEdit.RESERVA_ID, current.getId());
        intent.putExtra(ReservaEdit.RESERVA_NOM_CLIENTE, current.getNomCliente());
        intent.putExtra(ReservaEdit.RESERVA_NUM_CLIENTE, current.getNumCliente());
        mStartUpdateReserva.launch(intent);
    }


    /**
     * Lanzador de actividades para manejar la actualización de una reserva existente.
     * Llama al método {@link ExecuteActivityResult#process(Bundle, es.unizar.eina.M15_camping.database.Reserva)}
     * para actualizar la reserva en el {@link ReservaViewModel}.
     */
    ActivityResultLauncher<Intent> mStartUpdateReserva = newActivityResultLauncher(new ExecuteActivityResult() {
        @Override
        public void process(Bundle extras, es.unizar.eina.M15_camping.database.Reserva reserva) {
            int id = extras.getInt(ReservaEdit.RESERVA_ID);
            reserva.setId(id);
            mReservaViewModel.update(reserva);
        }
    });

}

/**
 * Interfaz funcional que se utiliza para procesar los resultados de actividades
 * relacionadas con reservas.
 */
interface ExecuteActivityResult {
    /**
     * Método para procesar los datos devueltos desde una actividad (desde MenuReservas).
     *
     * @param extras  Datos adicionales devueltos como {@link Bundle}.
     * @param reserva Objeto de tipo {@link es.unizar.eina.M15_camping.database.Reserva}
     *                creado o actualizado en la actividad.
     */
    void process(Bundle extras, es.unizar.eina.M15_camping.database.Reserva reserva);
}
