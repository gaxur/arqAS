package es.unizar.eina.M15_camping.database;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Clase que actua como una capa intermedia entre el DAO de {@link Reserva} y el resto de la aplicacion.
 * Proporciona metodos para realizar operaciones con acceso a datos y consultas relacionadas con reservas.
 * Ademas, gestiona relaciones entre reservas y parcelas mediante el DAO {@link ParcelaReservaDao}.
 */
public class ReservaRepository {
    private final ReservaDao mReservaDao;
    private final ParcelaReservaDao parcelaReservaDao;
    private final LiveData<List<Reserva>> mAllReservas;

    private final long TIMEOUT = 15000;

    /**
     * Constructor de ReservaRepository}.
     * Inicializa el DAO de {@link Reserva} y la lista de reservas ordenadas por fecha de entrada.
     *
     * @param application La aplicacion que contiene el contexto.
     */
    public ReservaRepository(Application application) {
        ParcelaReservaRoomDatabase db = ParcelaReservaRoomDatabase.getDatabase(application);
        mReservaDao = db.reservaDao();
        parcelaReservaDao = db.parcelaReservaDao();
        mAllReservas = mReservaDao.getReservasOrderedByFechaEntrada();
    }

    /**
     * Devuelve todas las reservas ordenadas por fecha de entrada (de menor a mayor).
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    public LiveData<List<Reserva>> getReservasOrderedByFechaEntrada() {
        return mAllReservas;
    }

    /**
     * Devuelve todas las reservas ordenadas por el nombre del cliente (alfabéticamente).
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    public LiveData<List<Reserva>> getReservasOrderedByNomCliente() {
        return mReservaDao.getReservasOrderedByNomCliente();
    }

    /**
     * Devuelve todas las reservas ordenadas por el numero del cliente.
     *
     * @return Un objeto {@link LiveData} que contiene la lista de reservas.
     */
    public LiveData<List<Reserva>> getReservasOrderedByNumCliente() {
        return mReservaDao.getReservasOrderedByNumCliente();
    }

    /**
     * Inserta una nueva relacion entre una reserva y una parcela.
     *
     * @param reservaId    El identificador de la reserva.
     * @param parcelaId    El identificador de la parcela.
     * @param numOcupantes El numero de ocupantes asignados a la parcela.
     */
    public void insertOrUpdateParcelaReservaRel(int reservaId, int parcelaId, int numOcupantes) {
        Executors.newSingleThreadExecutor().execute(() -> {
            int existingOccupants = parcelaReservaDao.getNumeroOcupantes(reservaId, parcelaId);

            if (existingOccupants > 0) {
                if (numOcupantes == 0) {
                    // Si los ocupantes se establecen en 0, elimina la relación
                    parcelaReservaDao.deleteParcelaReserva(reservaId, parcelaId);
                } else {
                    // Si ya existe, actualiza el registro
                    parcelaReservaDao.updateParcelaReserva(reservaId, parcelaId, numOcupantes);
                }
            } else {
                if (numOcupantes > 0) {
                    // Si no existe y numOcupantes > 0, inserta una nueva relación
                    ParcelaReservaRel relacion = new ParcelaReservaRel(reservaId, parcelaId, numOcupantes);
                    parcelaReservaDao.insert(relacion);
                }
                // Si numOcupantes es 0 y no existe relación, no hacer nada
            }
        });
    }

    /**
     * Inserta o actualiza una relación entre una parcela y una reserva, asegurando que el número de ocupantes
     * no exceda el límite permitido por la parcela. Si el número de ocupantes supera el máximo permitido,
     * la relación no se crea.
     *
     * <p><b>Comportamiento:</b></p>
     * <ul>
     *     <li>Si ya existe una relación entre la reserva y la parcela:
     *         <p>
     *         - Si {@code numOcupantes} es 0, la relación se elimina.<br>
     *         - Si {@code numOcupantes} > 0, la relación se actualiza con el nuevo número de ocupantes.
     *         </p>
     *     </li>
     *     <li>Si no existe una relación y {@code numOcupantes} > 0, se crea una nueva relación.</li>
     * </ul>
     *
     * @param reservaId    El ID de la reserva a la que se asociará la parcela.
     * @param parcelaId    El ID de la parcela que se asociará a la reserva.
     * @param numOcupantes El número de ocupantes que se intentará asociar a la parcela.
     * @return Un objeto {@link Future} que indica el estado de la operación. Si el número de ocupantes supera el límite
     * permitido por la parcela, la operación se cancela y se retorna {@code null}.
     */
    public Future<Void> insertOrUpdateParcelaReservaRelAsync(int reservaId, int parcelaId, int numOcupantes) {
        return Executors.newSingleThreadExecutor().submit(() -> {
            // Obtener la parcela para verificar su capacidad máxima
            Parcela parcela = parcelaReservaDao.getParcelaById(parcelaId);
            if (parcela != null && numOcupantes > parcela.getNMaxOcup()) {
                Log.d("ParcelaReservaRel", "Error: Número de ocupantes (" + numOcupantes + ") supera el límite permitido (" + parcela.getNMaxOcup() + ")");
                return null; // No insertar si el número de ocupantes supera el límite
            }

            int existingOccupants = parcelaReservaDao.getNumeroOcupantes(reservaId, parcelaId);

            if (existingOccupants > 0) {
                if (numOcupantes == 0) {
                    parcelaReservaDao.deleteParcelaReserva(reservaId, parcelaId);
                } else {
                    parcelaReservaDao.updateParcelaReserva(reservaId, parcelaId, numOcupantes);
                }
            } else {
                if (numOcupantes > 0) {
                    ParcelaReservaRel relacion = new ParcelaReservaRel(reservaId, parcelaId, numOcupantes);
                    parcelaReservaDao.insert(relacion);
                }
            }
            return null;
        });
    }

    /**
     * Elimina una relacion entre una reserva y una parcela especifica.
     *
     * @param reservaId El identificador de la reserva.
     * @param parcelaId El identificador de la parcela.
     */
    public void removeParcelaFromReserva(int reservaId, int parcelaId) {
        parcelaReservaDao.deleteParcelaReserva(reservaId, parcelaId);
    }

    /**
     * Obtiene todas las parcelas asociadas a una reserva especifica.
     *
     * @param reservaId El identificador de la reserva.
     * @return Una lista de objetos {@link Parcela} asociados a la reserva.
     */
    public List<Parcela> getParcelasByReservaId(int reservaId) {
        return parcelaReservaDao.getParcelasByReservaId(reservaId);
    }

    /**
     * Inserta una nueva reserva en la base de datos.
     *
     * @param reserva El objeto {@link Reserva} que se desea insertar.
     * @return El ID de la reserva insertada o -1 si ocurrio un error.
     */
    public long insert(Reserva reserva) {
        // Validar las fechas antes de ejecutar la inserción
        if (!areDatesValid(reserva.getFechaEntrada(), reserva.getFechaSalida())) {
            Log.d("ReservaRepository", "Fechas inválidas o formato incorrecto: " +
                    reserva.getFechaEntrada() + " - " + reserva.getFechaSalida());
            return -1; // Retorna -1 para indicar que la operación falló
        }

        // Validar el formato del número de cliente
        if (!isNumClienteValid(reserva.getNumCliente())) {
            Log.d("ReservaRepository", "Número de cliente inválido: " + reserva.getNumCliente());
            return -1; // Retorna -1 para indicar que la operación falló
        }

        Future<Long> future = ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.insert(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Verifica si el número de cliente es válido.
     * El número de cliente debe contener exactamente 9 dígitos.
     *
     * @param numCliente El número de cliente a validar.
     * @return `true` si es válido, `false` en caso contrario.
     */
    private boolean isNumClienteValid(String numCliente) {
        if (numCliente == null || numCliente.length() != 9) {
            return false; // Longitud incorrecta
        }
        return numCliente.matches("\\d+"); // Solo dígitos permitidos
    }


    private boolean areDatesValid(Date fechaEntrada, Date fechaSalida) {
        if (fechaEntrada == null || fechaSalida == null) {
            return false; // Fechas nulas no son válidas
        }

        // Verifica el formato de las fechas
        if (!isDateFormatValid(fechaEntrada) || !isDateFormatValid(fechaSalida)) {
            return false; // Formato incorrecto
        }

        // Verifica que la fecha de entrada sea anterior a la de salida
        if (!fechaEntrada.before(fechaSalida)) {
            return false; // Lógica de fechas incorrecta
        }

        // Verifica que la fecha de entrada no sea anterior a hoy
        Date now = new Date();
        if (fechaEntrada.before(now)) {
            return false; // Fecha de entrada es anterior a hoy
        }

        return true; // Todo está bien
    }

    private boolean isDateFormatValid(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false); // Requiere que la fecha siga estrictamente el formato
        try {
            // Convertimos la fecha a texto y la volvemos a parsear
            String dateStr = dateFormat.format(date);
            dateFormat.parse(dateStr); // Si no lanza excepción, el formato es válido
            return true;
        } catch (ParseException e) {
            return false; // Formato inválido
        }
    }

    /**
     * Actualiza una reserva existente en la base de datos.
     *
     * @param reserva El objeto {@link Reserva} que se desea actualizar.
     * @return El numero de filas afectadas o -1 si ocurrio un error.
     */
    public int update(Reserva reserva) {
        // Validar las fechas antes de ejecutar la actualización
        if (!areDatesValid(reserva.getFechaEntrada(), reserva.getFechaSalida())) {
            Log.d("ReservaRepository", "Fechas inválidas o formato incorrecto: " +
                    reserva.getFechaEntrada() + " - " + reserva.getFechaSalida());
            return -1; // Retorna -1 para indicar que la operación falló
        }

        // Validar el formato del número de cliente
        if (!isNumClienteValid(reserva.getNumCliente())) {
            Log.d("ReservaRepository", "Número de cliente inválido: " + reserva.getNumCliente());
            return -1; // Retorna -1 para indicar que la operación falló
        }

        Future<Integer> future = ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.update(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return -1;
        }
    }

    /**
     * Elimina una reserva existente de la base de datos.
     *
     * @param reserva El objeto {@link Reserva} que se desea eliminar.
     * @return El numero de filas afectadas o -1 si ocurrio un error.
     */
    public int delete(Reserva reserva) {
        try {
            return ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(() -> {
                Log.d("ReservaRepository", "Intentando eliminar la reserva con ID: " + reserva.getId());

                // Solo eliminamos la reserva, las relaciones se eliminan automáticamente por ON DELETE CASCADE
                int result = mReservaDao.delete(reserva);

                Log.d("ReservaRepository", "Resultado de la eliminación de la reserva: " + result);
                return result;
            }).get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return -1;
        }
    }

    public void deleteAllReservas() {
        ParcelaReservaRoomDatabase.databaseWriteExecutor.execute(() -> mReservaDao.deleteAll());
    }

    public void deleteAllParcelaReservaRelations() {
        ParcelaReservaRoomDatabase.databaseWriteExecutor.execute(() -> parcelaReservaDao.deleteAll());
    }

    public int getReservaCountById(int reservaId) {
        try {
            return ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(
                    () -> mReservaDao.getCountById(reservaId)
            ).get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Obtiene el número de ocupantes de una parcela específica asociada a una reserva.
     * Este método consulta la base de datos para obtener la cantidad de ocupantes asignados a
     * una parcela específica dentro de una reserva, usando los identificadores de la reserva y la parcela.
     *
     * @param reservaId El identificador único de la reserva que contiene la parcela.
     * @param parcelaId El identificador único de la parcela cuya cantidad de ocupantes se desea obtener.
     * @return El número de ocupantes asociados a la parcela en la reserva especificada. Si no se encuentra
     *         ninguna relación, se devuelve 0.
     */
    public int getNumeroOcupantes(int reservaId, int parcelaId) {
        return parcelaReservaDao.getNumeroOcupantes(reservaId, parcelaId);
    }

    /**
     * Elimina una reserva específica por su ID.
     *
     * @param reservaId El ID de la reserva a eliminar.
     */
    public void deleteReservaById(int reservaId) {
        Executors.newSingleThreadExecutor().execute(() -> {
            mReservaDao.deleteReservaById(reservaId);
        });
    }

    /**
     * Elimina todas las parcelas asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva de la cual se eliminarán las parcelas.
     */
    public void deleteParcelaReserva(int reservaId) {
        Executors.newSingleThreadExecutor().execute(() -> {
            mReservaDao.deleteParcelaReserva(reservaId);
        });
    }

    /**
     * Obtiene el número de parcelas asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva.
     * @return El número de parcelas asociadas.
     */
    public int getParcelasCountByReservaId(int reservaId) {
        try {
            return ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(
                    () -> parcelaReservaDao.getParcelasCountByReservaId(reservaId)
            ).get();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Obtiene el número de parcelas con numOcupantes >= 1 asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva.
     * @return El número de parcelas con ocupantes mayores o iguales a 1.
     */
    public int getParcelasConOcupantesCount(int reservaId) {
        try {
            return ParcelaReservaRoomDatabase.databaseWriteExecutor.submit(
                    () -> parcelaReservaDao.getParcelasConOcupantesCount(reservaId)
            ).get();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Obtiene la fecha de entrada de una reserva específica.
     *
     * @param reservaId ID de la reserva.
     * @return La fecha de entrada en milisegundos.
     */
    public long getFechaEntrada(int reservaId) {
        return mReservaDao.getFechaEntrada(reservaId);

    }

    /**
     * Obtiene la fecha de salida de una reserva específica.
     *
     * @param reservaId ID de la reserva.
     * @return La fecha de salida en milisegundos.
     */
    public long getFechaSalida(int reservaId) {
        return mReservaDao.getFechaSalida(reservaId);
    }

    /**
     * Actualiza el precio total de una reserva específica.
     *
     * @param reservaId ID de la reserva.
     * @param precioTotal Nuevo precio total para la reserva.
     */
    public void actualizarPrecioTotal(int reservaId, double precioTotal) {
        mReservaDao.actualizarPrecioTotal(reservaId, precioTotal);
    }

    /**
     * Obtiene todas las parcelas asociadas a una reserva específica.
     *
     * @param reservaId El ID de la reserva.
     * @return Lista de parcelas asociadas a la reserva.
     */
    public List<Parcela> getParcelasPorReserva(int reservaId) {
        return mReservaDao.getParcelasPorReserva(reservaId);
    }

    /**
     * Obtiene las parcelas disponibles entre las fechas dadas.
     *
     * @param fechaEntrada Fecha de entrada.
     * @param fechaSalida  Fecha de salida.
     * @return Lista de parcelas disponibles.
     */
    public List<Parcela> getParcelasDisponibles(long fechaEntrada, long fechaSalida) {
        return parcelaReservaDao.getParcelasDisponibles(fechaEntrada, fechaSalida);
    }

    /**
     * Obtiene una reserva específica de la base de datos utilizando su identificador único.
     * Este método consulta el DAO de reservas para recuperar los detalles de una reserva
     * en función del ID proporcionado.
     *
     * @param reservaId El identificador único de la reserva que se desea obtener.
     * @return El objeto {@link Reserva} correspondiente al ID proporcionado, o {@code null} si no se encuentra ninguna reserva con ese ID.
     */
    public Reserva getReservaById(int reservaId) {
        return mReservaDao.getReservaById(reservaId);
    }

    /**
     * Calcula el precio total de una reserva teniendo en cuenta las parcelas asociadas a la reserva,
     * el número de ocupantes en cada parcela y el número de días de la reserva.
     *
     * Este método obtiene las parcelas asociadas a la reserva, calcula el número de días entre la fecha de entrada
     * y la fecha de salida, y luego calcula el total sumando el precio por persona por cada parcela, multiplicado
     * por el número de ocupantes y el número de días.
     *
     * @param reservaId El identificador único de la reserva para la cual se desea calcular el precio total.
     * @return El precio total de la reserva. Si no se encuentran las parcelas o la reserva, devuelve 0.0.
     */
    public double calculateTotalPrice(int reservaId) {
        List<Parcela> parcelas = getParcelasPorReserva(reservaId);
        Reserva reserva = getReservaById(reservaId); // Método para obtener la reserva por ID

        if (parcelas == null || reserva == null) return 0.0;

        long fechaEntrada = reserva.getFechaEntrada().getTime();
        long fechaSalida = reserva.getFechaSalida().getTime();
        int dias = (int) ((fechaSalida - fechaEntrada) / (1000 * 60 * 60 * 24));

        double total = 0.0;
        for (Parcela parcela : parcelas) {
            int ocupantes = getNumeroOcupantes(reservaId, parcela.getId());
            total += ocupantes > 0 ? ocupantes * parcela.getPrecioPersona() * dias : 0;
        }

        // Redondear el total a 2 decimales usando BigDecimal
        BigDecimal bd = new BigDecimal(total).setScale(2, RoundingMode.HALF_UP);
        double precioFinal = bd.doubleValue();

        // Actualizar el precio en la reserva
        reserva.setPrecioTotal(precioFinal);
        update(reserva); // Llamada a tu método update en el repositorio

        return precioFinal;
    }

    /**
     * Obtiene una reserva por el nombre del cliente desde la base de datos.
     *
     * @param nombreCliente El nombre del cliente.
     * @return La reserva correspondiente, o null si no se encuentra.
     */
    public Reserva getReservaByCliente(String nombreCliente) {
        return mReservaDao.getReservaByCliente(nombreCliente);
    }
}

