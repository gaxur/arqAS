package es.unizar.eina.M15_camping.ui;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

import es.unizar.eina.M15_camping.database.Parcela;
import es.unizar.eina.M15_camping.database.ParcelaRepository;
import es.unizar.eina.M15_camping.database.ReservaRepository;

/**
 * Clase ViewModel para gestionar las parcelas.
 * Proporciona acceso a los datos de la BD a través del repositorio {@link ParcelaRepository}.
 * Gestiona operaciones de insercion, actualizacion y eliminacion, así como la ordenacion de parcelas.
 */
public class ParcelaViewModel extends AndroidViewModel {

    private final ParcelaRepository mRepository;
    private final LiveData<List<Parcela>> mAllParcelas;

    /**
     * Constructor de {@link ParcelaViewModel}.
     *
     * @param application La aplicacion que contiene el contexto de la actividad.
     */
    public ParcelaViewModel(Application application) {
        super(application);
        mRepository = new ParcelaRepository(application);
        mAllParcelas = mRepository.getAllParcelasOrderedByName(); // Lista predeterminada ordenada por nombre
    }

    /**
     * Devuelve todas las parcelas ordenadas por nombre (alfabéticamente)
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getAllParcelasOrderedByName() {
        return mAllParcelas;
    }

    /**
     * Devuelve todas las parcelas ordenadas por ID de menor a mayor
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getParcelasOrderedById() {
        return mRepository.getParcelasOrderedById();
    }

    /**
     * Devuelve todas las parcelas ordenadas por número maximo de ocupantes de menor a mayor
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getParcelasOrderedByMaxOccupants() {
        return mRepository.getParcelasOrderedByMaxOccupants();
    }

    /**
     * Devuelve todas las parcelas ordenadas por precio de menor a mayor
     *
     * @return Un objeto {@link LiveData} que contiene la lista de parcelas.
     */
    public LiveData<List<Parcela>> getParcelasOrderedByPrice() {
        return mRepository.getParcelasOrderedByPrice();
    }

    /**
     * Inserta una nueva parcela en la base de datos.
     *
     * @param parcela El objeto {@link Parcela} que se desea insertar.
     */
    public void insert(Parcela parcela) {
        mRepository.insert(parcela);
    }

    /**
     * Actualiza una parcela existente en la base de datos.
     *
     * @param parcela El objeto {@link Parcela} que se desea actualizar.
     */
    public void update(Parcela parcela) {
        mRepository.update(parcela);
    }

    /**
     * Elimina una parcela existente de la base de datos.
     *
     * @param parcela El objeto {@link Parcela} que se desea eliminar.
     */
    public void delete(Parcela parcela) {
        mRepository.delete(parcela);
    }
}
