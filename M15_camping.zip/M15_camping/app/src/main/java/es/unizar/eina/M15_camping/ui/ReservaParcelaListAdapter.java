package es.unizar.eina.M15_camping.ui;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import java.util.concurrent.Executors;

import es.unizar.eina.M15_camping.database.Parcela;
import es.unizar.eina.M15_camping.database.ReservaRepository;

public class ReservaParcelaListAdapter extends ListAdapter<Parcela, ReservaParcelaViewHolder> {
    private int position;
    private OnItemClickListener onClickListener;
    private final ReservaRepository reservaRepository;
    private final int reservaId;
    /**
     * Interfaz para manejar clics en los elementos del RecyclerView.
     */
    public interface OnItemClickListener {
        void onItemClick(Parcela parcela);
    }

    /**
     * Constructor del adaptador.
     *
     * @param diffCallback   El objeto {@link DiffUtil.ItemCallback} utilizado para calcular diferencias entre elementos.
     * @param reservaRepository El repositorio para consultar datos de la base de datos.
     * @param reservaId      El ID de la reserva actual.
     */
    public ReservaParcelaListAdapter(@NonNull DiffUtil.ItemCallback<Parcela> diffCallback,
                                     ReservaRepository reservaRepository, int reservaId) {
        super(diffCallback);
        this.reservaRepository = reservaRepository;
        this.reservaId = reservaId;
    }

    /**
     * Establece el listener para los clics normales.
     *
     * @param listener La implementación del listener.
     */
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onClickListener = listener;
    }


    /**
     * Crea un nuevo {@link ReservaParcelaViewHolder} para representar un elemento de la lista.
     *
     * @param parent   El grupo de vistas al que se añadirá la nueva vista.
     * @param viewType El tipo de vista del nuevo elemento.
     * @return Un nuevo {@link ReservaParcelaViewHolder}.
     */
    @Override
    public ReservaParcelaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return ReservaParcelaViewHolder.create(parent);
    }

    /**
     * Se vincula los datos del objeto {@link Parcela} a la vista representada por {@link ReservaParcelaViewHolder}.
     * Se configura un listener para manejar clics en los elementos.
     *
     * @param holder   El {@link ReservaParcelaViewHolder} que contiene la vista del elemento.
     * @param position La posición del elemento en la lista.
     */
    @Override
    public void onBindViewHolder(@NonNull ReservaParcelaViewHolder holder, int position) {
        Parcela current = getItem(position);
        holder.bind(current);

        // Consultar el número de ocupantes y actualizar el estado visual
        Executors.newSingleThreadExecutor().execute(() -> {
            int numOcupantes = reservaRepository.getNumeroOcupantes(reservaId, current.getId());
            holder.itemView.post(() -> {
                String statusText = numOcupantes > 0 ? "Añadido" : "No Añadido";
                int color = numOcupantes > 0 ? Color.GREEN : Color.RED;
                holder.updateStatus(statusText, color);
            });
        });

        // Configurar el OnClickListener para manejar clics en el elemento
        holder.itemView.setOnClickListener(v -> {
            if (onClickListener != null) {
                onClickListener.onItemClick(current); // Llamar al listener configurado
            }
        });
    }

    /**
     * Clase interna para calcular diferencias entre elementos de la lista de parcelas.
     */
    static class ParcelaDiff extends DiffUtil.ItemCallback<Parcela> {
        @Override
        public boolean areItemsTheSame(@NonNull Parcela oldItem, @NonNull Parcela newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Parcela oldItem, @NonNull Parcela newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }
}
